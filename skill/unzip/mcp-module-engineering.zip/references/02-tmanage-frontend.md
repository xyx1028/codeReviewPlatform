# tmanage 前端工程导航

## 1. 工程概况

- 根目录：`tmanage-frontend`
- 主应用：React 18、TypeScript 5.4、Vite 8、Ant Design 5、Axios、React Router、i18next、Vitest。
- 基址：`/console/`
- 开发代理：`/console/api`，默认指向 `http://localhost:18001`。
- scripts：`npm run dev`、`npm run mock`、`npm run build`（`tsc -b && vite build`）、`npm run test`（`vitest run`）。
- 状态管理：目标模块主要用 React hooks；未发现专用全局 store。
- 同仓子应用 `enterprise-center-frontend`：企业空间连接器导入和凭据管理，基址 `/console/enterprise/`。

## 2. 路由、菜单、权限

| 路由 | 页面 | 页面权限 | 主要动作权限 |
|---|---|---|---|
| `/connector` | `src/pages/ConnectorPage.tsx` | `tmanage.connector.view` | create/update/delete |
| `/mcp-service` | `src/pages/McpServicePage.tsx` | `tmanage.mcp_hub.view` | publish-as-tool/unpublish |
| `/my-tool` | `src/pages/MyToolPage.tsx` | `tmanage.mcp_hub.view` | 当前启停复用 unpublish 权限 |
| `/mcp-apps` | `src/pages/McpAppsPage.tsx` | `tmanage.mcp-app.view` | 与 Hub 租户实例不是一类对象 |

权限链：`CurrentUserContext` 调 `/auth/current-user`；`permission.ts` 支持精确/通配权限；`usePermissionCheck` 做按钮校验；`AppLayout` 维护菜单和 routePermissionMap。前端权限不是安全边界。

## 3. 连接器页面

关键文件：

- `src/pages/ConnectorPage.tsx`
- `src/components/ConnectorToolsModal.tsx`
- `src/components/ConnectorDisableConfirmModal.tsx`
- `src/api/index.ts`：`connectorApi`、`connectorCredentialApi`

`ConnectorPage` 页签：`erp`、`yzj`、`dc`、`lingeeMcp`。首次加载连接器、DC、cluster codes、类型、provisionable types、系统信息和云之家配置。`provisionable-types` 失败或为空时新增入口 fail-closed 隐藏。

### 3.1 私有部署三步向导

1. SaaS 地址、产品类型、名称。
2. MCP Server 地址、appId、appSecret，可测试。
3. 数据中心和凭据，最后做 MCP、数据中心、最低版本校验。

第二步进第三步会先 `POST /connector/provision`，传 `useStatus=N`、`skipConnectionTest=true` 取得 connector ID。第三步凭据单独落库；全部校验通过才更新为 Y，失败保留禁用草稿。全星号 Secret 表示不修改。

### 3.2 启停

私有部署启用前依次读取 mcp-config、测试 MCP、查询启用凭据、测试数据中心、检查版本，再调 `/status`。禁用先查 referenced-agents，有引用则二次确认并级联。公有云卡片直接走状态接口，需结合后端另一条启用闸门核对。DC 页签仍走普通 PUT。

### 3.3 工具拉取与查看

- `POST /cluster/{id}/tools/pull`
- 每 1.5 秒轮询 `GET /cluster/{id}/tools/pull/status`
- `RUNNING(FETCHING/PERSISTING) -> DONE/FAILED`
- “后台执行”只保存在当前组件内存，刷新会丢失。
- 工具查看走 `/cluster/{id}/tools` 和 `/{toolId}`，`ConnectorToolsModal` 按 domain 分组并展示 schema。

## 4. tmanage 运维预置“灵基MCP”页签

关键文件：

- `src/pages/LingeeMcpPanel.tsx`
- `src/components/ConnectorToolsModal.tsx`
- `src/api/index.ts`：`lingeeMcpApi`
- `src/docs/lingee-mcp-tool-auth-guide*.md`

API：

- `GET /lingee-mcp/list`
- `GET /lingee-mcp/{id}/tools`
- `POST /lingee-mcp/{id}/validate-swagger`
- `POST /lingee-mcp/{id}/import-tools`

该页签只展示 tmanage 运维直接预置的 `lingeeMcp_...`：连接器全局共享、工具按当前租户隔离。它不是 kdmanage `t_kdmanage_mcp_service` 的前端投影；kdmanage 下沉的 `lingge_...` 不应出现在这里。

页面支持认证指南、查看工具、Swagger 校验/导入；注释中的“拉取”已过期，实际没有 pull API 或按钮。

创建智能体时，`CreateInstanceWizard.tsx` 加载这类 Lingee MCP：模板需包含 `LINGEE_MCP_STANDALONE`，提交 `botConnectorTypeCode` 与 `botMcpConnectorId`。编辑/详情仍主要按普通 botConnectorId 回查，回显存在静态风险。

## 5. MCP Hub 租户目录

关键文件：

- `src/pages/McpServicePage.tsx`
- `src/components/McpInstanceEnableModal.tsx`
- `src/utils/mcpServiceAccess.ts`
- `src/components/mcpEnumLabels.ts`
- `src/api/index.ts`：`mcpServiceApi`

目录 API：page、category-counts、sources、detail、versions。卡片动作由 `mcpStatus/paramProviders/authMethod/requiresUserAuthorization/requiresOAuthClientConfig/acceptsTenantCredentials/instanceEnabled/published` 等共同决定。

- 发布：`POST /{mcpCode}/publish-as-tool`
- 取消发布：`DELETE /{mcpCode}/published-tool`
- 配置成功不会自动发布。
- OFF_SHELF 禁止新发布/修改实例，但已发布工具可继续存在。

**源码契约冲突**：`mcpServiceAccess.requiresTenantConfiguration` 对 PERSONAL 非 OAuth 返回 false，页面会给出直接发布；后端当前对所有非 OFFICIAL 都要求 ENABLED 实例和可运行工具清单。修改按钮逻辑或排障时必须同时检查两端。

## 6. 租户 MCP 实例弹窗

打开时读取 `/mcp-service/{mcpCode}/instance/schema`，只给 key/configured，不返回真值。凭证位置为 HEADER、URL_PARAM、AK_SK。

- 已配置项显示 `******`。
- URL 参数拼入测试 URL。
- 测试带 mcpCode，后端补已保存值。
- 非 OAuth 保存前必须测试。
- OAuth 走 discovery，必要时动态注册；已有 Client ID 不重复注册。
- 保存走 `POST /mcp-service/instance/enable`。
- `disableInstance` client 已定义但页面未接停用入口。

## 7. 我的工具

`MyToolPage.tsx` + `myToolApi`：page、detail、toggle-enabled。底层与普通工具共表，以 `sourceMcpCode` 分流。页面有请求序号保护，但用中文 `MCP服务取消发布` 判断是否允许重新启用，文案变化会破坏逻辑。

## 8. 企业中心子应用

`tmanage-frontend/enterprise-center-frontend` 提供 ERP 连接器导入、详情、凭据 upsert 和连接测试。`ConnectorShareModal` 和 revoke client 存在但未挂载页面。

## 9. 前端取证与排障

1. 浏览器 Network：保留完整 URL、method、status、业务 code/message、request/response 字段和 timing；凭证值必须脱敏。
2. 浏览器 Console：检查路由 basename、chunk、CORS、未处理 Promise、React error，不把 console 文案当后端根因。
3. Vite/dev terminal：确认代理目标、mode、预加载或 HMR 错误；mock 模式不覆盖 MCP 业务 API。
4. `/auth/current-user`、权限数组和租户请求头。
5. 新增入口不见时查 provisionable-types。
6. 拉取卡住时区分初始 POST 与 status 轮询。
7. 实例按钮错误时核对全部能力字段和上述 PERSONAL 契约冲突。
8. schema 的 configured/sensitive 当前按字符串 `'true'/'false'` 处理。
9. timeout 可填 600 秒，但实例测试 Axios 仍可能受全局 30 秒限制。
10. 雪花 ID 优先使用 string，避免 Number 精度损失。

## 10. 常见需求改动点

| 需求 | 文件 |
|---|---|
| 连接器卡片/向导/启停 | `ConnectorPage.tsx`、`api/index.ts`、i18n、CSS |
| 工具分组和 schema | `ConnectorToolsModal.tsx` |
| 运维预置 Lingee MCP | `LingeeMcpPanel.tsx`、`api/index.ts`、后端 LingeeMcp Service |
| Lingee MCP 绑定智能体 | `CreateInstanceWizard.tsx`、`api/agentInstance.ts`，并检查编辑/详情 |
| Hub 卡片决策 | `McpServicePage.tsx`、`mcpServiceAccess.ts` 及测试 |
| 实例凭证/OAuth | `McpInstanceEnableModal.tsx`、`mcpServiceApi` |
| 派生工具 | `MyToolPage.tsx`、`myToolApi` |
| 路由/权限 | `App.tsx`、`AppLayout.tsx`、按钮所在页面 |
