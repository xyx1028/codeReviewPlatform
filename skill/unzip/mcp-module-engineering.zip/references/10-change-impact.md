# 需求改动影响矩阵

## 1. 通用检查清单

任何 MCP 模块需求先回答：

1. 对象属于租户连接器、集群连接器、独立 MCP 服务还是 Hub 实例？
2. 主数据在 kdmanage 还是 tmanage？
3. 是否跨系统下沉？业务键是什么？
4. 是否涉及历史数据、软删复活、版本快照或已发布工具？
5. 是否涉及 Secret 掩码三态、OAuth、AK/SK、HMAC 或租户隔离？
6. 是否影响定时刷新、缓存、锁、手动拉取？
7. 是否需要新 Flyway、索引、数据回填？
8. 最小验证是什么？

## 2. 新增/修改租户 ERP 连接器字段

至少检查：

### kdmanage

- 前端 `TenantErpConnectorDTO/VO`
- `TenantsPage` 表单、回显、normalize
- `TenantErpConnectorAppService`：replace、incremental、externalTenantId 局部覆盖、self-provision
- PO/Mapper/Assembler
- `TmanageErpConnectorSyncService.toItemPayload`
- OpenAPI DTO、callback DTO
- 新 Flyway 和索引

### tmanage

- backend sync DTO/Controller/Service/Mapper
- `Connector` 实体和自定义 SQL
- 普通创建、private provision、public provision、update
- frontend 类型、列表/详情/向导
- 缓存失效和兼容性事件

特别检查：字段是否属于 ERP 主表、系统集群还是凭据，避免写错表。

## 3. 新增产品类型或公有云 provider

- kdmanage/tmanage connector type 字典。
- `allowed-product-types`。
- `tianti-product-types` / `panshi-product-types`。
- 域名识别规则。
- 网关标识必填规则。
- 最低版本要求。
- kdmanage 天梯返回 productCode 映射。
- 两端下沉 typeCode/typeName。
- 前端候选常量和禁用文案。

漏配应响亮失败，不应默认猜 provider。

## 4. 修改集群连接器字段

### kdmanage

- Cluster create/update DTO、VO、Entity/PO、Assembler。
- Repository 唯一性和乐观锁。
- 列表/配置/连接测试。
- `TmanageClusterConnectorSyncService` payload。
- tenantEnvCode 路由和旧目标删除语义。

### tmanage

- `ClusterConnectorSyncRequest`
- `TmanageClusterConnector`
- `ClusterConnectorSyncService`
- 登录、工具拉取、缓存 key
- Lingee standalone 查询
- Flyway

还要检查独立 MCP 是否复用了同一 payload。

## 5. 修改工具字段或 compare 规则

- 远端 RemoteTool 解析。
- kdmanage cluster tool 和 mcp_service_tool。
- tmanage OLD 实体/Mapper。
- tmanage NEW `TmanageToolContent`、`CompareCodeCalculator`、Mapper XML。
- `ClusterToolsDiffSyncer` 与 `ClusterToolsSyncService.toContent`。
- Swagger 转换。
- 前端详情和 schema 展示。
- 缓存序列化和 GC。
- 历史 compareCode 是否需要回填。

展示字段是否参与 compareCode 必须明确；误加入会制造大规模无意义更新，误遗漏会使真实变化不可见。

## 6. 修改工具拉取策略

分别评估：

- kdmanage 集群新协议与旧协议。
- kdmanage 独立 MCP。
- tmanage OLD 自动拉取。
- tmanage NEW POLL/FULL/LAZY。
- 手动拉取状态和前端轮询。
- remote miss、token、ref/content cache。
- 空列表语义。
- lastPullTime 成败口径。
- 锁 TTL、并发和第三方限流。

## 7. 修改独立运行 MCP Server

先判定子型，禁止把两条链合并：

### A. kdmanage 管理的独立 MCP 服务实例（`lingge_...`）

- kdmanage `McpServiceAppService` CRUD、pull、Swagger。
- `mcpServiceApi` 和 `McpServicesPage`。
- `TmanageClusterConnectorSyncService.syncMcpServiceUpsert`，确保 `standalone=true`。
- 当前固定走默认 tmanage baseUrl/Secret，不按 tenantEnvCode 路由；若需求要按环境路由，必须先扩模型、payload 和存量归属。
- tmanage cluster sync 接收、全局工具消费和删除。
- 不进入 LingeeMcpPanel，不使用 `LINGEE_MCP_STANDALONE` 智能体绑定。

### B. tmanage 运维预置 Lingee MCP（`lingeeMcp_...`）

- tmanage `LingeeMcpController/Service/SwaggerService`。
- 运维预置 sys cluster，连接器全局、OLD 工具按 tenantId 隔离。
- `LingeeMcpPanel`、`lingeeMcpApi`。
- 智能体创建的 `LINGEE_MCP_STANDALONE` 绑定。
- 只提供列表、查看、Swagger 导入和认证说明；不假设存在 kdmanage CRUD 或拉取。

不要误改 Hub `McpHubService`，也不要把 `lingge_` 与 `lingeeMcp_` 作为同一对象的前缀兼容问题。

## 8. Hub 新增模板字段

### kdmanage 必查

- CreateDTO、UpdateDTO、VO。
- Domain Entity、PO、Assembler。
- `beforeSave/normalizeAuthFields`。
- create/update/getDetail/pageList。
- `recordVersion` 和版本表列/快照 JSON。
- 前端 create/update/detail/version。
- `McpEnterpriseResourceSyncService` payload。
- Flyway。

### tmanage 必查

- `McpServiceImportRequest`
- `McpService` 实体和目录表
- `McpHubService.applyImportFields`
- 导入复活、off-shelf、delete reset/purge
- page/detail/instanceSchema
- platform instance 抽取
- publishAsTool 运行投影
- runtime invocation/聚合 SQL
- tmanage 前端卡片、详情、实例弹窗
- Flyway

新增一个字段最常漏的是：版本快照、软删复活清理、发布 Tool 投影和运行端读取。

## 9. 新增鉴权方式或 provider 组合

必须端到端检查：

1. kdmanage 前端枚举、字段联动、掩码回显。
2. kdmanage DTO 校验和 `normalizeAuthFields`。
3. 连接测试、同源 Secret 恢复、工具测试。
4. 审核是否要求 connectionTested。
5. 下沉时哪些值保留、清空或只发结构。
6. tmanage import 校验。
7. 平台实例还是租户实例。
8. instance schema 结构和前端表单。
9. 实例就绪校验和 credential key 白名单。
10. 工具清单如何获取与刷新。
11. publishAsTool 如何投影 auth 配置。
12. kwork/runtime 如何获得用户或企业凭证。
13. 停用、删除、归属迁移时如何清敏感数据。

还要定义：OFFICIAL/ADMIN/PERSONAL 多值是否合法；不要沿用“contains”判断。

## 10. 修改 Hub 生命周期

涉及：

- kdmanage `McpHubService` 状态守卫。
- `PublishReviewAppService` 审核事务。
- review versionId 与最新版本校验。
- update 是否回 DRAFT。
- unpublish 的远端失败策略。
- delete 的远端失败策略。
- resync 可见性和权限。
- tmanage `markCatalogOffShelf/deleteCatalog/importFromBackend`。
- 已发布工具是否联动。
- 前端按钮和确认文案。

状态变化必须画出旧/新状态机并说明存量迁移。

## 11. 修改租户实例

- `McpInstanceEnableRequest`
- `McpInstance` 和 Flyway
- CONFIGURING/ENABLED/DISABLED 三态
- enable、prepare OAuth、disable、revive、purge
- instanceSchema
- credential replace/merge
- connection test anchor
- periodic catalog refresh
- product tools Mapper
- publishAsTool
- tmanage frontend modal/API

如果字段需要清成 null，确认 MyBatis update strategy 能真正写 NULL；必要时用专用 Mapper SQL。

## 12. 修改发布为工具

- `publishAsTool`
- Tool/ToolResource 实体和表
- toolCode 生成与稳定性
- `sourceMcpCode` 唯一键
- 目录/实例配置覆盖规则
- 至少一个 visible resource 门禁
- unpublish/deactivate/kwork 通知
- republish 复活和资源重建
- “我的工具”列表、详情、启停
- runtime backend API、OAuth 回调和个人凭据

必须评估已发布旧版本工具与目录新版本并存。

## 13. 修改发布范围 CUSTOM

- kdmanage TenantPicker、tenant options 权限。
- `t_kdmanage_mcp_tenant_ref`。
- 下沉 payload tenantCode 的解析优先级。
- tmanage `t_tmanage_mcp_tenant_scope`。
- 目录 page/category counts/sources/detail 的 scope 过滤。
- tenantSn/tenantTid 变化与历史 scope 的一致性。
- 删除/重建同编码时旧 scope 清理。

## 14. 修改敏感字段

- 数据库列类型和长度。
- TypeHandler 与 `@Sensitive`。
- 旧明文迁移与密文前缀。
- 写加密和 backfill 开关。
- 前端掩码长度与三态。
- 连接测试同源恢复。
- reveal 二次认证。
- 日志、审计、版本快照、下沉 payload 脱敏。
- 回滚到旧版本是否能识别新密文。

## 15. 修改权限或开放接口

- 前端菜单/路由。
- 后端类级和方法级权限。
- permission seed/同步数据。
- kdmanage visibleMenus。
- tmanage routePermissionMap。
- `/api/open/**` 是否显式验签。
- `/api/backend/**` HMAC Filter。
- 测试匿名、无权限、正确权限三种场景。

## 16. 数据库迁移检查

- 新文件放主应用 `src/main/resources/db/migration`。
- 使用项目要求的时间戳命名。
- 不修改已发布脚本。
- PostgreSQL 幂等 DDL/DML。
- 审计字段、注释、索引命名符合项目规范。
- 考虑部分唯一索引与软删。
- 评估存量 null/非法状态/重复数据。
- 明确是否需在线回填、批次和锁影响。
- 验证 Flyway validate 和实际扫描目录。

## 17. 验证矩阵

| 改动 | 最小验证 |
|---|---|
| 前端类型/交互 | typecheck/build + 目标流程 smoke |
| 后端业务逻辑 | 定向 unit/integration test 或 compile + API smoke |
| 下沉 payload | 发送端序列化测试 + 接收 DTO/Service 测试 |
| 数据库 | Flyway validate + 临时库迁移 + 索引核对 |
| 状态机 | 每条合法转换和非法转换 |
| Secret | 新建、掩码不改、覆盖、允许清空、日志不泄露 |
| OAuth | discovery、注册、回调、state 过期、重复注册保护 |
| 工具刷新 | 新增、修改、删除、空清单、失败保留、并发锁 |
| 删除/下架 | 本地、对端、已发布工具、凭据清理、失败回滚 |

验证结果必须引用真实命令退出码或响应，不写预期通过。
