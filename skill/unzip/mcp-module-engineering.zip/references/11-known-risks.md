# 已知风险与契约漂移

> 静态代码事实与风险清单，不代表线上事故。源码互相矛盾可标“契约冲突已确认”；是否在线上触发仍需 HTTP、日志、DB 或测试证据。

## P0/P1：安全

### 1. kdmanage OpenMcpService 入口疑似无应用内鉴权

`/api/open/v1/mcp-services/validate-and-import` 位于 permitAll，Controller 未见 ExternalApiAuthService.verify，匿名时设置 SYSTEM user。可能由网关保护，但应用自身证据不足。

### 2. 共享 Backend HMAC Secret 为空会跳过验签

共享 Filter 的权威键是 `kwork.microservice-call.auth.secret-key`。Secret 为空时 Verifier 不启用。`kwork.backend-auth.*` 是其他/旧消费者，不能替代该检查。

### 3. Hub 历史多 provider CSV 清值口径不一致

serverUrl/urlParams 使用 officialOnly；headers/AKSK 部分字段使用“包含 OFFICIAL”。`OFFICIAL,PERSONAL` 可能把个人凭证真值当平台值下发。先查存量再统一合法组合和清值矩阵。

### 4. 部分 Secret 可能明文存储

- tmanage xacGwIdentity 未见 TypeHandler。
- tmanage MCP secret 写加密开关默认关闭。
- kdmanage independent MCP appSecret 未见 TypeHandler。
- kdmanage Hub AKSK appSecret 运行代码与迁移注释冲突。
- TManage cluster syncSecretKey 未见字段 TypeHandler。

需核对真实配置/数据并设计向前兼容回填和回滚。

## P1：跨系统一致性

### 5. kdmanage ERP 缺项不能驱动 tmanage 删除

kdmanage replace 会逻辑删本地缺项，tmanage batch 接收是 upsert-only，可能对端残留。

### 6. 集群删除级联不完整

tmanage 业务 connector 以字符串 clusterCode 引用；系统集群删除可能未清业务 connector、新 ref/meta/关系。

### 7. tmanage 删除业务 connector 未清 NEW ref

`t_tmanage_connector_tool_ref` 无 FK，deleteConnector 未见清理，可能形成孤儿并阻止 content GC。

### 8. sync-bind accepted 但实际 no-op

tmanage 当前只记录 deprecated/ignored，调用方不能把 accepted 当已写关系。

### 9. Hub 审核存在陈旧版本窗口

MCP approve 未见锁资源并校验 review 仍 PENDING、versionId 仍最新。在途审核后更新/删除可能批准旧快照。

### 10. 下架/删除失败策略不同

approve 下沉失败回滚；普通 unpublish 远端失败只 WARN；delete 远端失败回滚。需对账/补偿和准确产品文案。

### 11. 跨服务非分布式事务

Hub approve、Swagger import、cluster CRUD 都可能对端成功后本地后续失败。不能以本地状态单独证明对端状态。

## P1/P2：已确认源码契约冲突

### 12. PERSONAL 非 OAuth 的实例要求冲突

- 前端 `mcpServiceAccess.requiresTenantConfiguration` 对 PERSONAL 非 OAuth 返回 false。
- 后端 `requiresTenantInstance` 对所有非 OFFICIAL 的 ADMIN/PERSONAL 返回 true，publish 还要求可运行工具。

源码冲突已确认；是否线上触发待证。应统一以后端能力字段驱动 UI，补端到端测试。

### 13. tmanage 卡片状态入口与更新入口闸门不同

`updateUseStatusWithCascade` 与 `updateConnector` 的公有云启用校验路径不同。需确认 MANUAL public 从卡片启用是否绕过探活/凭据闸门。

### 14. tmanage Lingee MCP 智能体只完整接了创建链

Create DTO 支持 botConnectorTypeCode/botMcpConnectorId，编辑/详情仍主要按普通 botConnectorId 回查，可能无法回显。

### 15. Lingee MCP 注释曾写拉取，但功能范围无拉取

当前只列表、查看、认证说明、Swagger 导入。不要依据旧注释承诺 pull。

### 16. tmanage disableInstance client 未接 UI

后端/API client 有停用，MCP Service 页面无入口。

### 17. kdmanage 多项 client/handler 未接 UI

cluster/independent MCP changeStatus、cluster Swagger、Hub resync/reveal/即时 visibility、expiry 和 visibilityScopes 编辑等存在隐藏或未接能力。

## P2：两种 standalone 易误分类

### 18. `lingge_` 与 `lingeeMcp_` 是有意分开的模型

- `lingge_`：kdmanage independent MCP 下沉，全局工具，默认 tmanage 目标。
- `lingeeMcp_`：tmanage 运维预置，连接器全局、工具 tenant 隔离，进入 Lingee 页签。

风险不是“前缀不一致”，而是开发/排障把两者当同一对象，进而错误补推、改名或改查询。

### 19. kdmanage independent MCP 不按 tenantEnvCode 路由

普通 cluster 可解析目标 tmanage；syncMcpServiceUpsert 固定默认 baseUrl/Secret且不带 tenantEnvCode。多环境下可能写到非预期默认集群。

## P2：工具同步/调度

### 20. NEW 读路径可能没有定时写入者

read-from=NEW 时 OLD job 跳过；NEW sync job 需显式 enabled。必须查 Nacos。

### 21. Redis 锁无自动续租

任务超过 TTL 可能重复执行，墙钟预算只覆盖部分任务。

### 22. tmanage 前端轮询可能重叠

1.5s interval 小于 15s request timeout，无取消、退避或最大失败次数。

### 23. 后台拉取标记仅前端内存

刷新后可能再次 POST，依赖后端 cooldown/锁。

### 24. cluster 与 independent MCP 空列表语义相反

cluster 空列表可清空；independent MCP replaceTools 空列表 return 保留旧数据。

### 25. independent MCP pull 后前端不刷新主列表

lastPullTime/version 可能陈旧并触发后续乐观锁问题。

### 26. OLD/NEW 工具模型并存

配置、手动/定时拉取和页面读取可能命中不同模型，必须先确认 read-from 和任务装配。

### 27. 专用重试在本地事务内 sleep

普通 cluster/independent MCP CRUD 的网络重试会拉长事务、连接和锁占用。

## P2：数据库约束

### 28. tmanage credential 缺数据库唯一兜底

应用按 `(connectorId,appId)` upsert，未见等价唯一索引；并发可重复，LIMIT 1 不确定。

### 29. kdmanage independent MCP clusterCode/URL 唯一主要靠应用

数据库缺等价唯一索引时存在并发窗口。

### 30. 大量关联无 FK

绕过 Service 或异常中断可形成孤儿。补 FK 前先审计存量和线上锁影响。

### 31. 状态多为裸字符串

部分表无 CHECK、Service 不校验；前端未知状态可能默认显示启用。

## P2/P3：前端/文档

### 32. tmanage schema boolean 使用字符串

前端按 `'true'/'false'` 判断 configured/sensitive；后端改 boolean 会静默破坏。

### 33. tmanage serverUrl override 判定可能漏无模板场景

`serverUrlOverridden` 依赖 template 非空；模板空、租户手填时可能提交 undefined。

### 34. tmanage “未分类”筛选不一致

统计替换空 domain，筛选直接比较 domainCode，点击未分类可能空结果。

### 35. MyTool 依赖中文 disableReason

后端文案变化可能错误开放重新启用。

### 36. kdmanage 类型/供应商注释有旧模型

部分注释仍称 provider 归属 MCP type；当前两维度正交。

### 37. Hub 详情 OAuth 判断可能漏家族成员

部分代码只判断 OAUTH2，可能漏 PKCE/client credentials。

### 38. 双 lockfile/mock 漂移

安装前确认团队包管理器，避免重写 lock；mock 不能证明业务可用。

## 使用方式

- 新需求：逐项检查相关风险并明确是否纳入范围。
- 排障：风险仅是假设，除“源码冲突已确认”外仍需运行证据；源码冲突也不等于线上事故。
- 修复：同步更新本清单的状态和源码依据。
