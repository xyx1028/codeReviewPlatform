# 数据模型、业务键与字段真义

> 静态代码/迁移快照。线上结构、索引和数据必须只读确认。

## 1. 模型总览

| 领域 | kdmanage | tmanage | 键/隔离 |
|---|---|---|---|
| 租户 ERP | `t_kdmanage_tenant_erp_connector` | `t_tmanage_connector` | 选择后的 tenantCode -> 本地 tenantId；最终 `(tenant_id,connector_code)` |
| ERP 凭据 | 密钥交换材料 | `t_tmanage_connector_credential` | connector + applicationId/dataCenterId |
| 集群连接器 | `t_kdmanage_cluster_connector` | `t_tmanage_sys_cluster_connector` | clusterCode |
| 工具 OLD | kd cluster tool | `t_tmanage_sys_cluster_connector_tool` | connector/tenant/account/tool |
| 工具 NEW | 无同类去重表 | `t_tmanage_sys_tool_content` + `t_tmanage_connector_tool_ref` | compareCode；connectorId+toolName |
| kdmanage 独立 MCP | `t_kdmanage_mcp_service` + tool | sys cluster + 全局工具 | `lingge_...`、standalone=true |
| tmanage 运维 Lingee MCP | 无 | sys cluster + OLD tool | `lingeeMcp_...`；连接器全局、工具 tenant_id 隔离 |
| Hub 模板/目录 | `t_kdmanage_mcp` 全家桶 | `t_tmanage_mcp` 全家桶 | mcpCode |
| Hub 租户实例 | 无 | `t_tmanage_mcp_instance` + credential | tenantId+mcpCode |
| Hub 发布工具 | 无 | `t_tmanage_tool` + resource | tenantId+sourceMcpCode |

## 2. ERP 租户键和连接器键

### 2.1 跨系统租户值

- tenantSn 与 tenantTid 是候选标识，不是共同组成一个复合键。
- 常规发送端优先 tenantSn，空时回退 tenantTid，得到 tenantCode。
- ERP 批量 payload 字段当前仍叫 `tenantTid`，但值实际是 tenantCode。
- tmanage 用该值查 `t_tmanage_sys_tenant.tenant_code`，得到本地数字 tenantId。
- 最终 connector upsert 键是 `(tenant_id,connector_code)`。
- self-provision 明确只以 tenantSn 定位，不回退 tenantTid。

### 2.2 kdmanage ERP 表

`t_kdmanage_tenant_erp_connector`：tenant_id、external_tenant_id、connector_code/name/type、product_code、cluster_number、connector_url、data_center_*、use_status、version/is_deleted/audit。

- connector_url 是 ERP/SaaS 地址。
- cluster_number 存 clusterCode。
- 活跃 `(tenant_id,connector_code)` 唯一。
- externalTenantId 可多行；dataCenterId 主要由服务层校验唯一。

### 2.3 tmanage ERP 表

`t_tmanage_connector`：tenant_id、connector_code、external_tenant_id、connector_url、saas_url、data_center_*、cluster_code、use_status、connector_type、product_type、saas_env_type、source、erp_version。

- connector_url 是 ERP/SaaS 地址。
- saas_url 停止新写。
- source 为 MANUAL/KD_PUSH。
- 唯一性由历史自动编码和 MANUAL 来源的部分索引演进，没有覆盖所有来源的通用唯一索引。

`t_tmanage_connector_credential`：connector_id、app_name/id/secret、xac_gw_identity、json_config、use_status。应用层按 `(connectorId,applicationId)` upsert，但未核对到同等数据库唯一键。

## 3. 集群连接器

### kdmanage

`t_kdmanage_cluster_connector`：typeId、name、clusterCode、MCP URL、appId/Secret、status、tenantEnvCode、lastPullTime、version/isDeleted/audit。

- 活跃 name 唯一。
- 活跃 `(cluster_code,COALESCE(tenant_env_code,''))` 唯一。

### tmanage

`t_tmanage_sys_cluster_connector`：clusterCode、name/desc、typeId、MCP URL、appId/Secret、status、isStandalone。name 和 clusterCode 通常唯一。`t_tmanage_sys_connector_type` 以 typeCode 跨库建档。

## 4. 集群工具

### OLD

`t_tmanage_sys_cluster_connector_tool`：connectorId、可选 tenantId、erpAccountId、domain/application/tool/schema/meta/compareCode/serviceUrl。

- 普通旧集群工具可带 account 维度。
- tmanage 运维 Lingee MCP 工具必须带 tenantId，并由代码显式过滤。
- kdmanage `lingge_` 独立 MCP 下沉工具是全局共享，不应按 Lingee 页签 tenant 隔离理解。

### NEW

`t_tmanage_sys_tool_content` 以 compareCode SHA-256 全局去重；`t_tmanage_connector_tool_ref` 以 `(connector_id,tool_name)` 唯一引用。read-from 决定权威读模型。

## 5. 两种 standalone 模型

### 5.1 kdmanage 独立 MCP 服务

`t_kdmanage_mcp_service`：clusterCode、typeId、name/desc、URL、appId/Secret、status、lastPullTime、version/isDeleted。tool 表含 domain/application/tool/title/desc/serviceUrl/schema。

- clusterCode 通常 `lingge_...`。
- 下沉为 tmanage sys cluster `is_standalone=true`。
- 工具按全局共享模型。
- 不落 `t_tmanage_mcp_instance`，也不进入 Lingee MCP 页签。

### 5.2 tmanage 运维预置 Lingee MCP

- 无 kdmanage 主表。
- 运维直接写 tmanage sys cluster，`cluster_code=lingeeMcp_...`、standalone、ACTIVE。
- 工具写 OLD 表并带当前 tenantId。
- 列表和校验同时要求 standalone + 前缀；这是与 `lingge_` 有意隔离，不是漂移。

## 6. MCP Hub：kdmanage

`t_kdmanage_mcp`：code/name/desc、主 type、provider/team/version、server/auth/providers、headers/url params、OAuth/AKSK/inputMode/stateless、validDays/expiresAt、identity、tenantScope、visibility、preset、status、version/isDeleted/audit。

子表：type_ref、tool、version、i18n、tenant_ref、type/type_i18n、provider/provider_i18n。

- mcpCode、mcpName 活跃唯一。
- type_ref 多选，第一个/isPrimary 为主类型。
- tool `(mcp_id,tool_name)` 唯一。
- version `(mcp_id,version_no)` 唯一。
- 历史迁移的 provider->type 描述已过时；当前供应商来源类型与 MCP 业务类型正交。

## 7. MCP Hub：tmanage

### 7.1 目录

`t_tmanage_mcp` 为全局目录，通常 tenant_id=0；mcpCode 跨系统 upsert；状态 PUBLISHED/OFF_SHELF；活跃唯一 `(tenant_id,mcp_code)`。子表含 type/provider/i18n/version/tenant_scope/tool。

### 7.2 实例

`t_tmanage_mcp_instance`：tenantId、mcpId/code、CONFIGURING/ENABLED/DISABLED、server override、OAuth、timeout/test/stateless/identity、isDeleted/version。活跃唯一 `(tenant_id,mcp_code)`。

`t_tmanage_mcp_instance_credential`：instanceId、mcpCode、location、key、加密 value；唯一 `(instance_id,param_location,param_key)`。

`t_tmanage_mcp_tool` 可承载平台模板工具（instanceId null）和租户实例探测工具（instanceId 非空）；实例工具部分唯一 `(mcp_instance_id,tool_name)`。

### 7.3 个人授权与身份

`t_tmanage_mcp_lingee_identity_selection`、`t_user_oauth`、OAuth 日志、个人 Bearer/API Key credential。真删除跨租户清，普通 OFF_SHELF 不清。

### 7.4 发布投影

`t_tmanage_tool.source_mcp_code` 标识 Hub 派生工具；活跃 `(tenant_id,source_mcp_code)` 部分唯一。resource 在发布时重建；取消发布保留 Tool/Resource，重新发布复用 ID。

## 8. 状态

| 对象 | 状态 |
|---|---|
| kdmanage 集群/独立 MCP | ACTIVE/DISABLED |
| ERP connector | Y/N |
| kdmanage Hub | DRAFT/PENDING_REVIEW/PUBLISHED/REJECTED |
| tmanage Hub 目录 | PUBLISHED/OFF_SHELF 等 |
| tmanage Hub 实例 | CONFIGURING/ENABLED/DISABLED |
| 派生工具 | toolStatus + enabled + disableReason |

## 9. 敏感字段只读原则

禁止直接输出 Secret、private key、OAuth token/client secret、credential value、headers/url params 真值。URL 使用 `split_part(url,'?',1)` 或应用层只输出 scheme/host/port。可查询 `IS NOT NULL`、长度、密文前缀、configured、状态、时间和引用数。

安全示例：

```sql
SELECT id, cluster_code, status,
       app_secret IS NOT NULL AS secret_configured,
       update_time
FROM t_tmanage_sys_cluster_connector
WHERE cluster_code = :cluster_code;
```

## 10. 关键迁移

### tmanage

- `V20260507170000__cluster_connector_runtime.sql`
- `V20260515100000__create_sys_connector_type.sql`
- `V20260808100000__create_tool_content_and_connector_tool_ref.sql`
- `V20260811150001__create_mcp_service_catalog.sql`
- `V20260812150000__create_mcp_instance_and_tenant_scope.sql`
- `V20260813100000__publish_mcp_into_tool.sql`
- 后续 OAuth、AKSK、identity、stateless、实例工具、cursor 迁移。

### kdmanage

- `V6__cluster_connector.sql` 及演进
- `V20260513120000__tenant_erp_connector.sql` 及演进
- `V20260519200000__mcp_service.sql`
- `V20260811110000__mcp_hub_tables.sql` 及 scope/OAuth/AKSK/expiry/identity/i18n/stateless 演进

只新增迁移，不修改已发布脚本。
