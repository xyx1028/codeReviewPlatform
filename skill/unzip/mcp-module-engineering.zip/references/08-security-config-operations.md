# 鉴权、配置与运行任务

## 1. 调用通道

| 通道 | 调用方 | 认证 | 租户来源 |
|---|---|---|---|
| tmanage 前台 | tmanage frontend | Session/FrontendAuth + 权限 AOP | Session/请求上下文 |
| kdmanage 管理端 | kdmanage frontend | JWT + Security + PermissionAspect | 用户上下文 |
| kdmanage OpenAPI | 外部/tmanage | Bearer ticket 或 Controller 显式 verify | ticket/请求 |
| kdmanage -> tmanage backend | kdmanage | X-Kwork V2 HMAC/兼容旧签名 | X-Tmanage-TenantId |
| tmanage Open API | kwork/Job | `@TokenVerify` | Token |

## 2. tmanage 前台与租户隔离

- 权限前缀：`tmanage.connector`、`tmanage.mcp_hub`。
- connector list 方法级 view 被注释，但类级权限仍存在；实际 AOP 组合需代码/运行确认。
- Backend tenant filter 依次尝试 X-Tenant-Id、query tenantId、X-Tmanage-TenantId，并按 tenantCode 查本地 tenantId。
- 普通租户表自动隔离；provider scope SELECT 可见平台+当前租户，写仍当前租户。
- `@IgnoreAllInterceptors` 跨租户 SQL 必须显式带 tenant/mcp/id。
- 异步任务复制 TenantContext 后必须 finally clear。

## 3. 共享 Backend HMAC

- 入口：`/api/backend/**`。
- V2：method + 排序 query + body SHA-256 + timestamp；multipart 不签 body。
- 兼容旧 X-Tmanage-Sign/Timestamp。
- 失败通常 HTTP 401、`5000013001`。
- **权威配置键：`kwork.microservice-call.auth.secret-key`**。
- 原因：共享 `BackendAuthFilter` 由 `MicroserviceCallProperties(prefix="kwork.microservice-call")` 的 auth 配置装配。
- Secret 为空时 Verifier 未启用，Filter 跳过验签。
- `kwork.backend-auth.*` 可能被仓库内其他旧 Filter/业务读取，但不能用来判断共享 BackendAuthFilter 是否启用。
- kdmanage 默认 signer/endpoint resolver 同样应与 SDK Secret 对齐；排障需确认两端实际绑定值、Filter bean 和时钟。

## 4. kdmanage 安全

### JWT/权限

- HS512，Secret 至少 64 字节；校验 env、jti 黑名单、用户状态。
- PermissionAspect 解析方法级 RequiresPermission 和类级前缀。
- 主要权限：environment.cluster_connector、mcp_service、tenant_erp_connector、mcp_hub、mcp_type、mcp_provider、platform.publish_review。
- 页面按钮无细权限不代表后端允许。

### OpenAPI

SecurityConfig 对 `/api/open/**`、`/api/backend/**` permitAll。每个开放入口必须检查：显式 verify、client ACTIVE、ticket/signature、timestamp/replay、限流、匿名 SYSTEM user。

已知待核实：OpenMcpServiceController.validateAndImport 未见显式 verify。

## 5. 敏感数据

绝不输出 appSecret、syncSecret、ERP 私钥、OAuth Secret/token、Header/URL credential、HMAC/KMS Secret。允许查询 IS NOT NULL、长度、密文前缀、configured、更新时间、状态、引用数。URL 只展示去 query 的 scheme/host/port。

掩码：tmanage 常用 `******`，kdmanage Hub 常用 `********`。掩码不能落库为真值。数据库补旧 Secret 前必须做权限和同源校验。

## 6. SSRF

所有可配置 URL 测试须解析 scheme/host/port，处理 DNS、重定向和同源恢复。不同 guard 的私网规则不完全一致。需访问内网时使用明确白名单/受控开关，不永久整体关闭。

## 7. tmanage 配置

| 键 | 作用 |
|---|---|
| `kwork.connector.provision.allowed-product-types` | 私有自助入口；空即关闭 |
| `kwork.connector.provision.max-manual-count` | 手动上限 |
| `kwork.connector.mcp-param.*` | provider/域名/网关身份 |
| `kwork.cluster-connector.read-from` | OLD/NEW 读路径 |
| `kwork.cluster-connector.auto-pull.*` | OLD 任务 |
| `kwork.cluster-connector.sync.*` | NEW 同步 |
| `kwork.mcp.tool-catalog-refresh.*` | 租户实例工具刷新 |
| `kwork.refresh-round.*` | 并发/预算 |
| `kwork.mcp.oauth.redirect-uri-base` | OAuth 回调 |
| `kwork.microservice-call.auth.secret-key` | 共享 BackendAuthFilter HMAC |
| `kwork.sensitive.*` | 加密与回填 |

## 8. kdmanage 配置

| 键 | 作用 |
|---|---|
| `manage.sync.mcp.enabled` | Hub 下沉 |
| `manage.sync.cluster-connector.enabled` | cluster + independent MCP 下沉 |
| `manage.sync.erp-connector.enabled` | ERP 下沉 |
| `manage.sync.retry.*` / `timeout-ms` | 专用同步重试/超时 |
| `manage.mcp.hub-tool-refresh.*` | OFFICIAL 清单刷新 |
| `erp.key-exchange.*` | 天梯/公钥/应用信息 |
| `manage.openapi.*` | ticket/TTL/锁 |
| `manage.jwt.*` | 管理 JWT |
| `kwork.microservice-call.auth.secret-key` | SDK HMAC Secret |
| `manage.tool.url-param-view-password` | 敏感 reveal 二次密码 |

真实值以 Nacos/环境变量为准。

## 9. 定时任务错峰

| 分钟 | 系统 | 任务 |
|---|---|---|
| 0/30 | kdmanage | 普通已发布工具刷新 |
| 5/35 | tmanage | MCP 租户实例刷新 |
| 15/45 | tmanage | 普通租户自建工具刷新 |
| 20/50 | kdmanage | Hub OFFICIAL 刷新 |

调整一个任务前评估整体第三方出网峰值。

## 10. 锁、缓存、事务

- tmanage：全局/目标/租户锁、manual status、内容/ref/miss/token 缓存；Redis 锁无自动续租。
- kdmanage：self-provision advisory/repository lock；Hub refresh 分布式锁。
- KworkServiceClient 与专用 WebClient 两套调用并存。
- 普通 cluster/independent MCP CRUD 在本地事务中同步阻塞下沉，专用三次重试的 sleep 会拉长事务。
- ERP 常规路径多为 afterCommit 非严格，self-provision 为严格分阶段；必须按入口判断。

## 11. 构建验证

### tmanage frontend

```bash
npm run build
npm run test
```

### kdmanage frontend

```bash
pnpm typecheck
pnpm build
```

### tmanage backend

```bash
mvn -pl tmanage -am -DskipTests compile
```

在 `tmanage-backend` 根执行；这是基于当前模块名的候选命令，必须观察真实退出码。

### kdmanage backend

```bash
mvn -pl kdmanage-backend -am -DskipTests compile
```

已有相关测试时再跑定向 test。不得把 compile 当联调通过。

## 12. 高风险操作

生产写库/删除、resync/replay/补推、改 HMAC/JWT/AES/KMS、开启回填、切 OLD/NEW、删除全局集群/目录、调高并发、放开私网 SSRF，均需先说明影响、失败模式和回滚并获得确认。
