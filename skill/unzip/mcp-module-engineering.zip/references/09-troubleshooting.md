# MCP 模块故障排查手册

> 先证据、后根因；先只读、后补偿。生产写库、删除、重放、补推必须先获得明确授权。

## 1. 最小证据

- 环境、部署版本/分支、时间窗。
- tenantSn、tenantTid、tmanage tenantCode/tenantId，以及发送端实际选择的 tenantCode。
- connectorCode、clusterCode、mcpCode。
- 页面、操作、完整 API、HTTP status、业务 code/message。
- 真实传播的 traceId。
- requestId：先确认是否写进 Header/payload；cluster/independent MCP/ERP 专用同步的 requestId 当前通常只在 kdmanage 本地日志，不能据它跨端检索。
- 最近创建、编辑、审核、下架、拉取、部署或配置时间。

```text
前端路由/权限
 -> 入口 Controller
 -> 本地 Service/DB
 -> 跨系统出站
 -> 对端鉴权/租户上下文
 -> 对端 DB
 -> 外部 ERP/MCP
 -> 工具存储/缓存
 -> 发布运行投影
```

## 2. 前端取证

### tmanage

- 浏览器 Network：`/console/api` 完整请求、status、Result code/message、timing、租户头；Secret 值脱敏。
- Console：basename、chunk、CORS、Promise/React 错误。
- Vite terminal：proxy target、mode、HMR/预加载错误。

### kdmanage

- Network：`/kdmanage/api`、cookie、401 登录跳转、403、version 请求值。
- `/api/v1/users/me` 的 permissions + visibleMenus。
- Console/Vite terminal：lazy chunk、basename、proxy 18000。
- `dev:mock` 只 mock 用户/菜单，不证明 MCP API 可用。

## 3. 日志关键词

### tmanage

`[cluster-tools-sync]`、`[cluster-tools-pull]`、`[cluster-sync]`、`[manual-pull]`、`[cluster-tools-diff]`、`[tools-cache]`、`[remote-miss]`、`[mcp-token]`、`[erp-connector-sync]`、`[backend-erp-credential]`、`[erp-credential-upsert]`、`[connector-credential-sync]`、`[kdmanage-call]`、`[erp-self-provision]`、`[erp-fusion]`、`[McpHub]`、`[McpDiscoveredTool]`、`[mcpToolCatalogRefresh]`、`[BackendContextFilter]`。

### kdmanage

`[cluster-sync]`、`[mcp-sync]`、`[ResourceSync]`、`[McpHub]`、`[cluster-connector-test]`、`[mcp-service-test]`、`[swagger-import]`、`[erp-connector-sync]`、`[self-managed-erp]`、`[erp-key-exchange]`、`[erp-credential-provision]`、`[erp-public-key-callback]`、`[erp-credential-callback]`、`[ErpTokenClient]`、`[security-audit]`。

独立 MCP 下沉起始日志是 `[mcp-sync]`，共用 HTTP retry 内部仍打印 `[cluster-sync]`。跨端优先用真实 traceId；没有传播 ID 时按业务键 + 时间窗 + URL/status 关联。

## 4. 安全只读 SQL

### 4.1 tmanage ERP connector

```sql
SELECT id, tenant_id, connector_code, external_tenant_id,
       connector_type, product_type, saas_env_type, source,
       split_part(connector_url, '?', 1) AS erp_url_without_query,
       data_center_id, cluster_code, use_status, create_time, update_time
FROM t_tmanage_connector
WHERE tenant_id = :tenant_id AND connector_code = :connector_code;
```

### 4.2 tmanage sys cluster

```sql
SELECT id, cluster_code, name, status, is_standalone, connector_type_id,
       split_part(connector_url, '?', 1) AS mcp_url_without_query,
       app_id IS NOT NULL AS app_id_configured,
       app_secret IS NOT NULL AS secret_configured,
       update_time
FROM t_tmanage_sys_cluster_connector
WHERE cluster_code = :cluster_code;
```

### 4.3 kdmanage cluster/ERP

```sql
SELECT id, cluster_code, tenant_env_code, status,
       split_part(connector_url, '?', 1) AS mcp_url_without_query,
       last_pull_time, version, update_time
FROM t_kdmanage_cluster_connector
WHERE cluster_code = :cluster_code AND is_deleted = 0;

SELECT id, tenant_id, external_tenant_id, connector_code,
       cluster_number, split_part(connector_url, '?', 1) AS erp_url_without_query,
       data_center_id, use_status, version, update_time
FROM t_kdmanage_tenant_erp_connector
WHERE tenant_id = :tenant_id AND connector_code = :connector_code AND is_deleted = 0;
```

### 4.4 Hub current rows

```sql
SELECT id, mcp_code, current_version, mcp_status,
       auth_method, param_providers, tenant_scope_type,
       connection_tested, expires_at, version, update_time
FROM t_kdmanage_mcp
WHERE mcp_code = :mcp_code AND is_deleted = 0;

SELECT id, tenant_id, mcp_code, current_version, mcp_status,
       auth_method, param_providers, tenant_scope_type,
       expires_at, update_time
FROM t_tmanage_mcp
WHERE tenant_id = 0 AND mcp_code = :mcp_code AND is_deleted = 0;

SELECT id, tenant_id, mcp_code, instance_status,
       connection_tested, stateless_capable, update_time
FROM t_tmanage_mcp_instance
WHERE tenant_id = :tenant_id AND mcp_code = :mcp_code AND is_deleted = 0;

SELECT id, tenant_id, source_mcp_code, tool_code,
       current_version, tool_status, enabled, disable_reason, update_time
FROM t_tmanage_tool
WHERE tenant_id = :tenant_id AND source_mcp_code = :mcp_code AND is_deleted = 0;
```

需要历史时另查 `is_deleted=1` 并明确标为历史行。禁止 select Secret、private key、token、credential value 或带 query 的 URL。

## 5. 新增连接器入口不见

1. `tmanage.connector.create`。
2. `/connector/provisionable-types` 是否成功非空。
3. Nacos allowed-product-types。
4. connector type 是否 ACTIVE。
5. 浏览器是否因失败保持 undefined。

白名单空同时让前端隐藏、后端拒绝，不是单纯 UI 问题。

## 6. 公有云连接器卡在开通中/clusterCode 空

1. tmanage 预建行是否 `MANUAL+public+N+cluster NULL`。
2. `/kdmanage-provision` 的 overallStatus/stages/requestId。
3. kdmanage `[self-managed-erp]`：tenantSn、天梯 cluster、cluster stage、tenant connector stage。
4. tmanage `[cluster-sync]`、`[erp-connector-sync]`，按 traceId 或业务键+时间关联。
5. 回推 connectorCode 是否与预建行一致。
6. tenantEnvCode 是否路由到正确 tmanage。
7. payload `tenantTid` 的值是否为预期 tenantCode，能否命中 tmanage tenant_code。
8. HMAC、tenant header、时钟。

kdmanage 本地有 cluster 行不等于 tmanage 已回填。

## 7. 普通集群在 kdmanage 有、tmanage 无

1. `manage.sync.cluster-connector.enabled`。
2. tenantEnvCode 对应 TManage cluster 的 ACTIVE/baseUrl/Secret。
3. kdmanage 本地 requestId 查 `[cluster-sync]`；tmanage 用 traceId 或业务键时间窗。
4. 401：`kwork.microservice-call.auth.secret-key`、签名字节、timestamp。
5. 400：X-Tmanage-TenantId 是否命中 tenant_code、typeCode/必填字段。
6. 404：context path、代理、对端版本。
7. tmanage BackendContextFilter/Controller 日志。
8. 补推前确认 clusterCode 幂等和影响。

## 8. kdmanage 独立 MCP 下沉问题

1. 查 `t_kdmanage_mcp_service` 的 `lingge_` clusterCode/status。
2. `[mcp-sync]` 起点和 `[cluster-sync]` HTTP 重试。
3. payload 是否 standalone=true。
4. **目标固定为默认 tmanage baseUrl/Secret，不按 tenantEnvCode 路由**；多环境先确认默认目标。
5. tmanage 查 sys cluster 和全局工具。
6. 不去 `LingeeMcpService` 或“灵基MCP”页签找它；该页签只认 `lingeeMcp_` 运维预置对象。

## 9. tmanage“灵基MCP”页签为空

1. 这是 tmanage 运维预置模型，不查 kdmanage mcp_service。
2. sys cluster 必须 `is_standalone=true`、ACTIVE、clusterCode `lingeeMcp_`。
3. `LingeeMcpService.list` 是否命中。
4. 工具需在 OLD 工具表且 tenant_id=当前租户。
5. Swagger import 的远端 registry 与本地 tenant tool 是否都成功。
6. 不把 `lingge_` 改名或重复同步来解决。

## 10. 工具拉取卡住

### tmanage

- 初始 POST 是否受理，status 是否 NONE/RUNNING。
- phase FETCHING/PERSISTING。
- business connector 存在、clusterCode、ACTIVE sys cluster。
- 目标锁、租户锁、cooldown、TTL。
- MCP login/token、scope/tools 网络。
- PERSISTING 查 DB 锁、批次、索引。
- 前端 1.5s interval 小于 15s timeout，慢请求可能重叠；关页面不停止后端任务。

### kdmanage

- 登录、registry/Gateway 分段。
- lastPullTime 失败也更新。
- cluster 空列表可清空；independent MCP 空列表保留旧工具。
- pull 后 version/列表是否刷新。

## 11. 工具为空或数量不一致

1. 对象：普通 cluster、kd independent MCP、tmanage Lingee preset、Hub template、tenant instance。
2. tmanage OLD/NEW read-from。
3. NEW ref/content join；OLD tenant/account 过滤。
4. remote miss、FULL/POLL/LAZY。
5. Hub 只下发 visible=1。
6. OFFICIAL 以 kdmanage 为权威；ADMIN/PERSONAL 以 tmanage 实例探测为权威。
7. 定时刷新空清单会保留旧值。
8. 目录有工具不等于实例或 Tool resource 有工具。

## 12. Hub 审核通过、tmanage 无目录

1. kd MCP 是否 PUBLISHED、review APPROVED。
2. manage.sync.mcp.enabled。
3. `[ResourceSync] syncMcpOnImport`、目标 `/api/backend/mcp-service/import`。
4. 服务发现、`kwork.microservice-call.auth.secret-key`、X-Tmanage-TenantId。
5. tmanage `[McpHub]`、backend tenant context。
6. 当前平台目录行应 tenant_id=0/is_deleted=0；再查 OFF_SHELF/CUSTOM scope。
7. 两端非分布式事务，必须同时查。
8. 补推前确认 PUBLISHED 和开关；前端 resync 按钮当前隐藏。

## 13. tmanage Hub 卡片按钮不对

核对 mcpStatus、scope、isDeleted、paramProviders、authMethod、requiresUserAuthorization、requiresOAuthClientConfig、acceptsTenantCredentials、instanceEnabled、published。

**源码契约冲突已确认**：前端对 PERSONAL 非 OAuth 判无需配置，后端对所有非 OFFICIAL 要求 ENABLED 实例。运行影响需证据；直接发布被拒时优先对照 `mcpServiceAccess.ts` 与 `McpHubService.requiresTenantInstance/publishAsTool`。

## 14. 实例连接测试 401/400

- authMethod、paramLocation。
- 首次值不是掩码；编辑 configured 和 mcpCode。
- HEADER 放 headersJson；URL_PARAM 拼 URL；AK_SK 走 Gateway。
- `{tenantId}` 是否替换。
- host/port 改变时后端同源保护不会补旧 Secret。
- 浏览器 30s timeout 是否先中止。
- 查看第三方原始错误摘要，不能记录凭证。

## 15. OAuth 失败

- serverType/URL、resource/auth server metadata。
- discovery endpoints、registration endpoint。
- 已有 Client ID 时跳过注册是正常保护。
- 动态 Secret 只返回一次，需立即保存。
- redirect-uri-base 与第三方登记完全一致。
- CONFIGURING anchor、Redis state/result 5 分钟 TTL、结果读后删。
- postMessage 跨源失败时依赖轮询。

## 16. 实例启用但不能发布

- 实例必须 ENABLED，不是 CONFIGURING。
- tenantId 正确；平台实例不能替代 ADMIN/PERSONAL。
- identity selection。
- 实例工具清单至少一个 visible。
- PERSONAL 临时测试是否落实例锚点。
- 目录/Tool 版本。
- connectionTested 不是充分条件。

## 17. 下架后工具仍可用

- kdmanage Hub 下架只 OFF_SHELF，设计上保留已发布工具。
- tmanage 取消发布才 `enabled=0` 并通知 kwork。
- 停用实例也不联动工具。

若已取消发布仍可用：查 Tool enabled/disableReason、kwork 通知、事务回滚、运行缓存/安装副本。

## 18. 403/重定向/跨系统 HTTP

- tmanage：current-user、routePermissionMap、类/方法权限，MCP 专用测试接口。
- kdmanage：users/me permissions+visibleMenus；ProtectedRoute 无权限直接重定向；后端完整权限路径。

| 状态 | 检查 |
|---|---|
| 401 | JWT/ticket/HMAC、共享 SDK Secret、timestamp/body、用户/client 状态 |
| 400 | tenant header、DTO、typeCode、状态值、Result body |
| 403 | 后端权限，不是菜单 |
| 404 | context path、代理、接口版本/部署 |
| 409 | version、唯一键、并发 upsert |
| 5xx | 对端日志、网络、DB、第三方、重试与回滚 |

## 19. 根因报告

必须写：已证实/高概率/缺证据等级、直接证据、影响、解释链、排除项、临时/永久修复、风险/回滚、真实验证结果、未验证项。静态风险匹配不能写成已发生事故；源码互相矛盾可写“契约冲突已确认”，线上是否触发另行证明。
