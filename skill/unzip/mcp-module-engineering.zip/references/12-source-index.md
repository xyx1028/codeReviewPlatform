# 源码与 Symbol 索引

> 所有路径相对工作区根目录；可直接用于文件搜索。大型文件先搜 symbol。

## 1. tmanage frontend

### 基础

- `tmanage-frontend/package.json`
- `tmanage-frontend/vite.config.ts`
- `tmanage-frontend/src/App.tsx`
- `tmanage-frontend/src/api/request.ts`
- `tmanage-frontend/src/api/index.ts`
- `tmanage-frontend/src/components/AppLayout.tsx`
- `tmanage-frontend/src/components/CurrentUserContext.tsx`
- `tmanage-frontend/src/hooks/usePermissionCheck.ts`
- `tmanage-frontend/src/utils/permission.ts`

### Connector

- `tmanage-frontend/src/pages/ConnectorPage.tsx`
  - `ConnectorPage`
  - `verifyPrivateConnectorEnable`
  - `applyConnectorStatus`
  - `SaasConnectorWizard`
  - `WizardCredentialStep`
- `tmanage-frontend/src/components/ConnectorToolsModal.tsx`
- `tmanage-frontend/src/components/ConnectorDisableConfirmModal.tsx`
- `tmanage-frontend/src/api/index.ts`：`connectorApi`、`connectorCredentialApi`

### tmanage 运维预置 Lingee MCP

- `tmanage-frontend/src/pages/LingeeMcpPanel.tsx`
- `tmanage-frontend/src/api/index.ts`：`lingeeMcpApi`
- `tmanage-frontend/src/components/CreateInstanceWizard.tsx`
  - `filteredConnectors`
  - `lingeeMcpSelected`
  - `handleSubmit`
- `tmanage-frontend/src/api/agentInstance.ts`：`CreateInstanceDTO`

### Hub/实例/派生工具

- `tmanage-frontend/src/pages/McpServicePage.tsx`
- `tmanage-frontend/src/components/McpInstanceEnableModal.tsx`
  - `runConnectionTest`
  - `handleDiscovery`
  - `handleOk`
- `tmanage-frontend/src/utils/mcpServiceAccess.ts`
- `tmanage-frontend/src/pages/MyToolPage.tsx`
- `tmanage-frontend/src/components/mcpEnumLabels.ts`
- `tmanage-frontend/src/api/index.ts`：`McpServiceCard`、`McpServiceDetail`、`mcpServiceApi`、`myToolApi`

### 企业中心

- `tmanage-frontend/enterprise-center-frontend/src/pages/ConnectorPage.tsx`
- `tmanage-frontend/enterprise-center-frontend/src/components/modals/ConnectorImportModal.tsx`
- `tmanage-frontend/enterprise-center-frontend/src/components/modals/ConnectorCredentialModal.tsx`
- `tmanage-frontend/enterprise-center-frontend/src/components/modals/ConnectorShareModal.tsx`
- `tmanage-frontend/enterprise-center-frontend/src/api/index.ts`

## 2. tmanage backend

根包：`tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage`

### Connector

- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/ConnectorController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/ConnectorService.java`
  - `createConnector`
  - `provisionConnector`
  - `provisionPublicConnector`
  - `testConnection`
  - `updateConnector`
  - `updateUseStatusWithCascade`
  - `deleteConnector`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/ConnectorCredentialController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/ConnectorCredentialService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/ConnectorCredentialSyncService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/erp/ConnectorCredentialUpsertServiceImpl.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/entity/Connector.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/entity/ConnectorCredential.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/ConnectorMapper.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/ConnectorCredentialMapper.java`

### kdmanage 回推 DTO/Controller

- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/backend/BackendClusterConnectorSyncController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/backend/BackendErpConnectorSyncController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/backend/BackendErpConnectorCredentialController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/dto/clusterconnector/ClusterConnectorSyncRequest.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/dto/erpconnector/ErpConnectorBatchSyncRequest.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/ClusterConnectorSyncService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/ErpConnectorSyncService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/KdmanageErpSelfProvisionService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/KdmanageErpBoundTenantService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/KdmanageHttpClient.java`

### Cluster tools

- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/ClusterToolController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ClusterConnectorToolsPullService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ClusterToolsSyncService.java`
  - `syncConnector`
  - `applyLazyTools`
  - `computeDiff`
  - `persist`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ClusterToolsDiffSyncer.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ManualPullService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ClusterProductToolsService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ToolContentService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/ConnectorToolRefService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/service/CompareCodeCalculator.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/task/ClusterToolsSyncJob.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/clustertools/task/ClusterConnectorToolsPullJobConfig.java`
- `tmanage-backend/tmanage/src/main/resources/mapper/TmanageClusterConnectorToolMapper.xml`
- `tmanage-backend/tmanage/src/main/resources/mapper/TmanageConnectorToolRefMapper.xml`
- `tmanage-backend/tmanage/src/main/resources/mapper/TmanageToolContentMapper.xml`

### tmanage 运维预置 Lingee MCP

- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/LingeeMcpController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/LingeeMcpService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/LingeeMcpSwaggerService.java`

### Hub

- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/McpServiceController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/controller/backend/BackendMcpServiceController.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/dto/McpServiceImportRequest.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/model/dto/McpInstanceEnableRequest.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpHubService.java`
  - `importFromBackend`
  - `markCatalogOffShelf`
  - `deleteCatalog`
  - `enableInstance`
  - `prepareOAuthInstance`
  - `prepareOAuthConnectionTest`
  - `disableInstance`
  - `testInstanceConnection`
  - `refreshInstanceToolCatalog`
  - `publishAsTool`
  - `unpublish`
  - `instanceSchema`
  - `syncTools`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpDiscoveredToolService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpToolCatalogRefreshService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/task/McpToolCatalogRefreshJob.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpOAuthService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpPublishedToolRuntimeService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/service/McpPublishedToolInvocationService.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/McpServiceMapper.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/McpInstanceMapper.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/McpInstanceCredentialMapper.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/McpServiceToolMapper.java`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/mapper/McpHubProductToolsMapper.java`

### 配置/租户/迁移

- `tmanage-backend/tmanage/src/main/resources/application.yml`
- `tmanage-backend/tmanage/src/main/java/com/kingdee/kwork/tmanage/tenant/TmanageBackendContextFilter.java`
- `tmanage-backend/manage-common/src/main/java/com/kingdee/kwork/tmanage/tenant/TenantContext.java`
- `tmanage-backend/tmanage/src/main/resources/db/migration/V20260808100000__create_tool_content_and_connector_tool_ref.sql`
- `tmanage-backend/tmanage/src/main/resources/db/migration/V20260812150000__create_mcp_instance_and_tenant_scope.sql`

## 3. kdmanage frontend

### 基础

- `kdmanage-frontend/package.json`
- `kdmanage-frontend/vite.config.ts`
- `kdmanage-frontend/src/router/index.tsx`
- `kdmanage-frontend/src/stores/auth-store.ts`
- `kdmanage-frontend/src/services/request.ts`
- `kdmanage-frontend/src/services/api.ts`
- `kdmanage-frontend/src/styles/global.css`

### Cluster/independent MCP/ERP

- `kdmanage-frontend/src/pages/ClusterConnectorsPage.tsx`
- `kdmanage-frontend/src/pages/McpServicesPage.tsx`
- `kdmanage-frontend/src/pages/ConnectorTypesPage.tsx`
- `kdmanage-frontend/src/pages/McpServiceConnectorTypesPage.tsx`
- `kdmanage-frontend/src/pages/TenantErpConnectorsPage.tsx`
- `kdmanage-frontend/src/pages/TenantsPage.tsx`

### Hub

- `kdmanage-frontend/src/pages/McpHubPage.tsx`
- `kdmanage-frontend/src/pages/McpCreateDialog.tsx`
- `kdmanage-frontend/src/pages/McpUpdateDialog.tsx`
- `kdmanage-frontend/src/pages/McpHubDetailModal.tsx`
- `kdmanage-frontend/src/pages/McpHubVersionModal.tsx`
- `kdmanage-frontend/src/pages/McpTypesPage.tsx`
- `kdmanage-frontend/src/pages/McpProvidersPage.tsx`
- `kdmanage-frontend/src/pages/PublishReviewPage.tsx`
- `kdmanage-frontend/src/components/mcp-hub/authMethod.ts`
- `kdmanage-frontend/src/components/mcp-hub/paramProvider.ts`
- `kdmanage-frontend/src/components/mcp-hub/TenantScopeField.tsx`
- `kdmanage-frontend/src/components/mcp-hub/TenantPickerModal.tsx`
- `kdmanage-frontend/src/components/mcp-hub/McpResourceActions.tsx`

## 4. kdmanage backend

根包：`kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage`

### Cluster

- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/ClusterConnectorController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/ClusterConnectorAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/repository/ClusterConnectorRepositoryImpl.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/TmanageClusterConnectorSyncService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/ClusterConnectorMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/ClusterConnectorToolMapper.java`

### Independent MCP

- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/McpServiceController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/OpenMcpServiceController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/McpServiceAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/repository/McpServiceRepositoryImpl.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpServiceMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpServiceToolMapper.java`

### ERP/OpenAPI/callback

- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/TenantErpConnectorController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/SelfManagedErpConnectorOpenApiController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/ErpCredentialCallbackController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/TenantErpConnectorAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/SelfManagedErpConnectorStageService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/erpkey/ErpCredentialProvisionServiceImpl.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/TmanageErpConnectorSyncService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/TmanageErpCredentialSyncServiceImpl.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/TmanageErpTokenClientImpl.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/TenantErpConnectorMapper.java`

### Hub

- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/McpController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/mcphub/McpHubService.java`
  - `createMcp`
  - `updateMcp`
  - `deleteMcp`
  - `submitReview`
  - `unpublish`
  - `resync`
  - `testConnection`
  - `testSavedAkSkConnection`
  - `refreshPublishedMcpTools`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/mcphub/McpTypeAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/mcphub/McpProviderAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/McpEnterpriseResourceSyncService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/PublishReviewAppService.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/controller/PublishReviewController.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/model/entity/mcphub/Mcp.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/model/po/mcphub/McpPO.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpToolMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpTypeMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpTypeRefMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpProviderMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpTenantRefMapper.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/mapper/McpVersionMapper.java`

### Tmanage client/security/config

- `kdmanage-backend/kdmanage-common/src/main/java/com/kingdee/kwork/manage/common/cluster/TmanageClient.java`
- `kdmanage-backend/kdmanage-common/src/main/java/com/kingdee/kwork/manage/common/cluster/TmanageBackendSigner.java`
- `kdmanage-backend/kdmanage-common/src/main/java/com/kingdee/kwork/manage/common/cluster/TmanageDefaultEndpointResolver.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/common/config/SecurityConfig.java`
- `kdmanage-backend/kdmanage-backend/src/main/java/com/kingdee/kwork/manage/service/ExternalApiAuthService.java`
- `kdmanage-backend/kdmanage-backend/src/main/resources/application.yml`
- `kdmanage-backend/kdmanage-backend/src/main/resources/db/migration/V20260811110000__mcp_hub_tables.sql`

## 5. 共享微服务 SDK

- `kwork-server/kwork-microservice-call/src/main/java/com/kingdee/kwork/microservice/call/web/BackendAuthFilter.java`
- `kwork-server/kwork-microservice-call/src/main/java/com/kingdee/kwork/microservice/call/properties/MicroserviceCallProperties.java`

共享 HMAC 权威键由后者的 `kwork.microservice-call.auth.secret-key` 提供。

## 6. 快速搜索词

| 目标 | 搜索词 |
|---|---|
| 公有预建/回填 | `awaitingClusterProvision`, `autoEnable`, `resolveConnectorCode` |
| 地址写反 | `resolveErpUrl`, `saveManualConnector` |
| 普通 cluster 下沉 | `sync-upsert`, `[cluster-sync]`, `tenantEnvCode` |
| kd independent MCP | `syncMcpServiceUpsert`, `lingge_`, `standalone` |
| tmanage Lingee preset | `LingeeMcpService`, `lingeeMcp_`, `LINGEE_MCP_STANDALONE` |
| Hub 下沉 | `syncMcpOnImport`, `importFromBackend` |
| 实例冲突 | `requiresTenantInstance`, `requiresTenantConfiguration` |
| 工具清单 | `persistDiscoveredTools`, `mergeDiscoveredTools`, `syncTools` |
| 发布门禁 | `rejectPublishWithoutRunnableResource` |
| OAuth | `prepareOAuthInstance`, `oauth-register-client`, `takeConnectionTestResult` |
| 删除 | `deleteCatalog`, `purgeByMcpCodeAcrossTenants` |
| 调度 | `tool-catalog-refresh`, `hub-tool-refresh`, `RefreshRoundRunner` |
