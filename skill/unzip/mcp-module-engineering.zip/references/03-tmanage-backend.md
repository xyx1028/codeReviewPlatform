# tmanage 后端工程导航

## 1. 工程概况

- 根目录：`tmanage-backend`
- 主应用模块：`tmanage-backend/tmanage`
- Java 17、Spring Boot 3.5.13、Spring MVC/WebFlux、Spring Security、MyBatis-Plus、PostgreSQL、Flyway、Redis Session、Nacos。
- 服务端口 18001，context path `/console`。
- Flyway：`tmanage/src/main/resources/db/migration`；Mapper XML：`tmanage/src/main/resources/mapper`。
- 候选编译命令：在 `tmanage-backend` 根执行 `mvn -pl tmanage -am -DskipTests compile`。仓库未定义唯一权威本地启动命令，必须以真实执行结果为准。

## 2. 租户连接器链路

```text
ConnectorController
 -> ConnectorService
 -> ConnectorMapper / ConnectorCredentialMapper / TmanageClusterConnectorMapper
 -> t_tmanage_connector / credential / sys_cluster_connector
```

关键文件：`ConnectorController`、`ConnectorService`、`ConnectorCredentialController/Service`、`Connector/ConnectorCredential`、对应 Mapper。

### 2.1 创建

- 普通 `createConnector`：要求 clusterNumber、connectorUrl。
- 私有 `provisionConnector`：ERP 地址和 MCP 地址分开；同事务写系统集群与业务连接器；第三步凭据可后置，N 为合法中间态；私有集群编码 `privateErp_...`。
- 公有 `provisionPublicConnector`：天梯分支先写 `MANUAL + public + N + cluster_code=NULL` 等 kdmanage 回推；磐石分支当前被显式拒绝。

### 2.2 字段真义

- `t_tmanage_connector.connector_url`：ERP/SaaS 地址。
- `t_tmanage_sys_cluster_connector.connector_url`：MCP Server 地址。
- `saas_url` 停止新写，只做存量回退。
- 手动行编辑 MCP 地址只能改集群表，不能覆盖主表 ERP 地址。

### 2.3 启停和删除

- `updateUseStatusWithCascade` 校验 Y/N，禁用同步企业空间副本并禁用引用实例；启用不自动恢复实例。
- `updateConnector` 是另一条更新路径，手动公有云 N->Y 的服务端闸门在此路径。
- `deleteConnector` 清 credential 和业务连接器，但未见同步删除系统集群或新工具 ref，需排查孤儿。

## 3. kdmanage ERP 回推

### 3.1 租户键映射

kdmanage payload 字段名为 `tenantTid`，实际值是发送端选出的 tenantCode（通常 tenantSn，空时回退 tenantTid；self-provision 明确只认 tenantSn）。tmanage 接收后按 `tenant_code` 查本地 tenantId，最终以 `(tenant_id,connector_code)` upsert。不要把原始 tenantTid 或 kdmanage tenant 主键直接当 tmanage tenantId。

### 3.2 ERP 连接器

```text
BackendErpConnectorSyncController
 -> ErpConnectorSyncService.syncBatchUpsert
 -> ConnectorMapper
```

- `POST /api/backend/erp-connector/sync-batch-upsert`
- upsert-only，不因缺项删除。
- 命中手动天梯预建行时窄回填 externalTenantId、ERP URL、clusterCode。

### 3.3 ERP 凭据

```text
BackendErpConnectorCredentialController
 -> ConnectorCredentialUpsertServiceImpl
 -> ConnectorCredentialMapper
```

- `POST /api/backend/erp-connector/credential/upsert`
- 先全部解密校验，再写凭据并启用连接器。
- 典型错误：TENANT_NOT_FOUND、ERP_PRIVATE_KEY_MISSING、ERP_CONNECTOR_NOT_FOUND、ERP_SECRET_DECRYPT_FAILED。

### 3.4 系统集群

`BackendClusterConnectorSyncController -> ClusterConnectorSyncService`，端点 sync-upsert/sync-delete/sync-bind。`sync-bind` 当前 deprecated/ignored，accepted 不代表写入关系。

## 4. 集群工具存储与拉取

### OLD

`t_tmanage_sys_cluster_connector_tool`，由 `ClusterConnectorToolsPullService`、`ClusterToolsDiffSyncer` 维护。

### NEW

- 内容：`t_tmanage_sys_tool_content`
- 引用：`t_tmanage_connector_tool_ref`
- Service：`ClusterToolsSyncService`
- compareCode 全局内容去重，引用唯一 `(connector_id,tool_name)`。
- POLL/FULL 可删除；LAZY 只增改，必须走 `applyLazyTools`。

手动拉取：`ClusterToolController -> ManualPullService -> ClusterToolsSyncService(FULL)`；Redis 状态 `ACCEPTED -> RUNNING(FETCHING/PERSISTING) -> DONE/FAILED`。

必须同时核对 read-from、旧 auto-pull、新 sync.enabled、锁 TTL、cooldown 和缓存。

## 5. 两种 standalone MCP

### 5.1 kdmanage 下沉的独立 MCP 服务

kdmanage `lingge_...` 通过 cluster sync 落 `t_tmanage_sys_cluster_connector.is_standalone=true`，工具是全局共享模型。它不由 `LingeeMcpService` 查询，也不进入“灵基MCP”页签。

### 5.2 tmanage 运维预置 Lingee MCP

```text
LingeeMcpController
 -> LingeeMcpService / LingeeMcpSwaggerService
 -> TmanageClusterConnectorMapper / TmanageClusterConnectorToolMapper
```

- 只认 `is_standalone=true + status=ACTIVE + cluster_code LIKE 'lingeeMcp_%'`。
- 连接器由运维直接写系统集群表，全局共享。
- 工具按 `tenant_id` 手工隔离。
- 功能仅列表、查看、Swagger 校验/导入；不提供新建、编辑、删除、连接测试或拉取。

## 6. MCP Hub 目录和实例

### 6.1 目录导入

`BackendMcpServiceController -> McpHubService.importFromBackend`。

- `POST /api/backend/mcp-service/import`
- `POST /{mcpCode}/off-shelf`
- `DELETE /{mcpCode}`

按 mcpCode 上锁和 upsert，软删行复活原 ID；同步类型、供应商、i18n、版本、工具、租户范围、OAuth、AK/SK、身份和 expiry。OFFICIAL 真凭证迁到 tenant_id=0 平台实例/凭据，目录保留模板。

### 6.2 租户实例

`McpServiceController -> McpHubService -> instance/credential/tool Mappers`。

- CONFIGURING：测试或 OAuth prepare 的锚点。
- ENABLED：可发布。
- DISABLED：停用后清敏感列并软删。
- OFFICIAL 通常无需租户实例。
- ADMIN 保存租户共享凭据。
- PERSONAL 不保存个人 Token，但后端当前仍要求租户实例承载配置和工具清单。
- 停用实例不自动停用派生工具。

### 6.3 测试和工具清单

普通测试走 `McpToolTestService`，AK/SK 走 Gateway。后端合并已存 HEADER/URL_PARAM/AK_SK；成功后 best-effort 固化实例工具和 stateless。固化失败不改变测试成功响应。

### 6.4 发布为工具

`publishAsTool` 要求目录可用、非 OFFICIAL 有 ENABLED 租户实例、身份选择完成、至少一个可运行可见资源；写/复活 `t_tmanage_tool` 并重建 resource。取消发布只置 enabled=0、写 disableReason 并通知 kwork，不删除 Tool。

## 7. 目录下架与删除

- `markCatalogOffShelf`：只改 OFF_SHELF，保留实例、凭据、派生工具。
- `deleteCatalog`：跨租户清派生工具、实例、实例/个人凭据、授权、目录关联，并通知 kwork；通知失败会回滚本地事务。

## 8. 鉴权与租户隔离

- 前台：`@RequiresPermission`。
- Open API：`@TokenVerify`。
- Backend：共享 SDK `BackendAuthFilter` 校验 X-Kwork V2/兼容签名。
- **共享 Filter 的权威配置是 `kwork.microservice-call.auth.secret-key`**（`MicroserviceCallProperties` 前缀 `kwork.microservice-call`）。为空时 Verifier 未启用并跳过校验。
- `kwork.backend-auth.*` 在仓库中仍可能被其他旧 Filter/业务消费，不能用它判断共享 BackendAuthFilter 是否开启；排障要先确认实际 Filter bean 和配置消费者。
- `TmanageBackendContextFilter` 将 tenantCode 解析成本地 tenantId。
- 跨租户 Mapper 使用 `@IgnoreAllInterceptors` 时必须自行带 tenant/mcp/id 条件。

## 9. 敏感字段

- Connector credential appSecret：AES TypeHandler + 响应脱敏。
- xacGwIdentity：响应脱敏，但实体未见加密 TypeHandler。
- 系统集群/Hub Secret：有专用 TypeHandler；仓库默认 MCP secret 写加密开关关闭，线上需查真实值。
- Hub serverUrl/headers/URL params/OAuth Secret/实例 credential：AES 或敏感注解。
- schema API 不返回 value，只给 configured。

## 10. 配置和任务

关键配置：

- `kwork.connector.provision.*`
- `kwork.connector.mcp-param.*`
- `kwork.cluster-connector.*`
- `kwork.mcp.tool-catalog-refresh.*`
- `kwork.refresh-round.*`
- `kwork.mcp.oauth.redirect-uri-base`
- `kwork.microservice-call.auth.secret-key`（共享 BackendAuthFilter）
- `kwork.sensitive.*`

任务：旧集群工具默认每 30 分但 NEW 模式跳过；新去重同步需 sync.enabled；MCP 实例刷新默认 5/35 分；普通工具刷新 15/45 分。

## 11. 日志关键词

`[cluster-tools-sync]`、`[cluster-tools-pull]`、`[cluster-sync]`、`[manual-pull]`、`[erp-connector-sync]`、`[backend-erp-credential]`、`[erp-credential-upsert]`、`[kdmanage-call]`、`[erp-self-provision]`、`[McpHub]`、`[McpDiscoveredTool]`、`[mcpToolCatalogRefresh]`、`[BackendContextFilter]`。

## 12. 最小验证

在 `tmanage-backend` 根目录候选命令：

```bash
mvn -pl tmanage -am -DskipTests compile
```

已有相关测试时运行定向 test。数据库变更检查 Flyway 文件名、幂等性和真实扫描目录；payload 变更做发送/接收 DTO 静态对照。不得把 compile 成功当跨系统联调成功。
