# 领域边界与跨系统架构

## 1. 系统职责

| 系统 | 定位 | MCP 模块核心职责 |
|---|---|---|
| kdmanage | 平台运营与主数据控制面 | 管租户/环境路由、连接器类型、集群连接器、kdmanage 独立 MCP 服务实例、MCP Hub 模板/类型/供应商/审核，并向 tmanage 下沉 |
| tmanage | 租户控制台与运行配置面 | 管租户连接器和凭据、集群工具拉取、tmanage 运维预置 Lingee MCP、Hub 目录消费、租户 MCP 实例、派生工具及运行配置 |
| 外部 ERP/天梯 | ERP 主数据和 MCP 集群信息源 | 提供 MCP 集群参数、ERP 应用信息、公钥绑定和回调 |
| 外部 MCP Server/Gateway | 工具协议端 | 提供登录、registry、initialize、tools/list、tools/call 等能力 |
| kwork | 运行消费端 | 消费 tmanage 发布的工具，处理终端用户授权和实际调用；本技能只覆盖与其交界处 |

## 2. 领域对象

### 2.1 租户 ERP 连接器

表示“租户的某个数据中心接入哪个 ERP 地址和哪个 MCP 集群”。

- kdmanage 主表：`t_kdmanage_tenant_erp_connector`
- tmanage 主表：`t_tmanage_connector`
- tmanage 凭据：`t_tmanage_connector_credential`
- 跨系统定位：发送端从 tenantSn/tenantTid 中按场景选择一个 tenantCode；tmanage 用它查本地 tenant，再以 `(tenant_id,connector_code)` upsert。
- 集群关联：kdmanage `cluster_number` / tmanage `cluster_code` 均承载 `clusterCode`。
- 状态：两端使用 `useStatus=Y/N`，但写入与启用职责不同。

### 2.2 集群连接器

表示平台登记的 MCP 集群入口和登录凭据。

- kdmanage：`t_kdmanage_cluster_connector`
- tmanage：`t_tmanage_sys_cluster_connector`
- 业务键：`clusterCode`
- 状态：`ACTIVE/DISABLED`
- tmanage 业务连接器通过 `t_tmanage_connector.cluster_code` 引用系统集群。

### 2.3 独立运行 MCP Server：两种不同模型

#### A. kdmanage 管理的独立 MCP 服务实例

- kdmanage：`t_kdmanage_mcp_service`、`t_kdmanage_mcp_service_tool`
- 编码通常为 `lingge_<16位数字>`。
- 复用 tmanage `/api/backend/cluster-connector/sync-upsert`，payload 带 `standalone=true`。
- tmanage 落 `t_tmanage_sys_cluster_connector`，工具为全局共享模型。
- 不进入 tmanage“灵基MCP”页签，也不使用 `LINGEE_MCP_STANDALONE` 智能体选择模型。
- 下沉固定走 `TmanageClusterConnectorSyncService` 的默认 baseUrl/Secret，不按 `tenantEnvCode` 选择目标，payload 也不带 tenantEnvCode。这与普通集群连接器按环境路由不同。

#### B. tmanage 运维预置的灵基MCP

- 运维直接预置 `t_tmanage_sys_cluster_connector`。
- `is_standalone=true` 且 `cluster_code` 前缀为 `lingeeMcp_`。
- 连接器全局共享，工具写 `t_tmanage_sys_cluster_connector_tool` 并按 `tenant_id` 隔离。
- 由 tmanage `/connector?tab=lingeeMcp` 展示，支持查看、认证说明和 Swagger 导入。
- 不由 kdmanage `t_kdmanage_mcp_service` 下沉产生。

两者都叫 standalone，但所有权、编码、工具隔离、页面入口和下沉方式不同。

### 2.4 MCP Hub 模板、目录、租户实例和派生工具

- kdmanage 模板：`t_kdmanage_mcp`
- kdmanage 子表：工具、类型、供应商、版本、租户范围和多语言
- tmanage 全局目录：`t_tmanage_mcp`，通常 `tenant_id=0`
- tmanage 平台或租户实例：`t_tmanage_mcp_instance`
- 实例凭据：`t_tmanage_mcp_instance_credential`
- 租户探测工具：`t_tmanage_mcp_tool.mcp_instance_id`
- 发布运行投影：`t_tmanage_tool`、`t_tmanage_tool_resource`
- 业务键：`mcpCode`

## 3. 关键业务键

| 键 | 用途 | 准确口径 |
|---|---|---|
| `tenantSn` / `tenantTid` | kdmanage 中的候选租户标识 | 不是共同组成跨系统复合键；发送端按具体链路选择一个 |
| `tenantCode` | 跨系统租户定位值 | 常优先 tenantSn，空时回退 tenantTid；self-provision 明确只认 tenantSn |
| payload `tenantTid` | ERP 批量同步字段名 | 当前实际承载上述 tenantCode；tmanage 接收后按 tenantCode 查租户 |
| tmanage `tenant_id` | 本地数据库主键 | 由 tenantCode 解析得到，最终与 connectorCode 组成本地 upsert 键 |
| `connectorCode` | 同租户 ERP 连接器业务键 | 公有云预建与 kdmanage 回推依靠该键命中 |
| `clusterCode` | 系统集群业务键 | kdmanage `clusterNumber` 字段通常承载它 |
| `mcpCode` | Hub 全链路业务键 | 目录、实例、版本和派生工具通过它关联 |
| `sourceMcpCode` | tmanage 派生工具来源 | 非空即与普通工具管理链分流 |

Hub CUSTOM 范围也按 tenantCode 匹配，但 scope payload 明确传 tenantCode；不要直接使用两端数据库主键。

## 4. 核心下沉链

### 4.1 普通集群连接器

```text
kdmanage ClusterConnector
 -> ClusterConnectorAppService
 -> t_kdmanage_cluster_connector
 -> 按 tenantEnvCode 解析目标 tmanage baseUrl/Secret
 -> TmanageClusterConnectorSyncService
 -> POST /api/backend/cluster-connector/sync-upsert
 -> tmanage ClusterConnectorSyncService
 -> t_tmanage_sys_cluster_connector
```

普通管理 CRUD 往往在本地事务中同步阻塞调用并重试，重试中的 sleep 会拉长事务。self-provision 则按阶段先提交本地，再严格下沉，允许部分完成后重试。

### 4.2 kdmanage 独立 MCP 服务实例

```text
kdmanage McpService
 -> McpServiceAppService
 -> t_kdmanage_mcp_service
 -> TmanageClusterConnectorSyncService.syncMcpServiceUpsert
 -> 默认 tmanage baseUrl/Secret（不按 tenantEnvCode 路由）
 -> cluster sync-upsert(standalone=true)
 -> t_tmanage_sys_cluster_connector
```

这条链与 tmanage 运维预置 `lingeeMcp_` 无关。

### 4.3 租户 ERP 连接器

```text
kdmanage tenant + ERP connectors
 -> 选择 tenantCode（常 tenantSn，空时 tenantTid）
 -> TmanageErpConnectorSyncService payload.tenantTid=tenantCode
 -> POST /api/backend/erp-connector/sync-batch-upsert
 -> tmanage 按 tenant_code 定位本地 tenant_id
 -> 按 (tenant_id,connector_code) upsert t_tmanage_connector
```

- tmanage 接收端是 upsert-only，不因 payload 缺项删除已有连接器。
- kdmanage 管理端整租户 replace 删除本地缺项，不能自动驱动 tmanage 删除。
- 天梯公有云链中，tmanage 可先建 `MANUAL + public + N + cluster_code=NULL` 的预建行，再由同 connectorCode 回推窄回填。

### 4.4 MCP Hub

```text
kdmanage MCP Hub
 -> DRAFT -> PENDING_REVIEW -> PUBLISHED
 -> McpEnterpriseResourceSyncService
 -> POST /api/backend/mcp-service/import
 -> tmanage McpHubService.importFromBackend
 -> t_tmanage_mcp + 平台实例/模板工具/范围/版本
 -> 租户启用实例
 -> t_tmanage_mcp_instance + credential + tenant tools
 -> 发布为工具
 -> t_tmanage_tool + t_tmanage_tool_resource
```

- 普通下架只把目录置 OFF_SHELF，保留实例、凭据和已发布工具。
- 真删除清目录关联、跨租户实例/凭据/个人授权和派生工具，并通知 kwork。
- kdmanage 审核发布与 tmanage 租户发布为工具是两个不同动作。

## 5. OFFICIAL / ADMIN / PERSONAL

| 提供方 | 凭证所有者 | tmanage 实例 | 工具清单来源 |
|---|---|---|---|
| OFFICIAL | 平台 | 通常使用 `tenant_id=0` 平台实例 | kdmanage 下发为权威 |
| ADMIN | 企业管理员/租户 | 租户实例必需 | 租户真实凭证连接测试和定时刷新 |
| PERSONAL | 终端用户；OAuth Client 可由管理员配置 | 后端当前要求租户实例承载配置和工具清单，但不保存个人 Token | 临时个人凭证测试、个人授权或匿名 tools/list |

**已确认源码契约冲突**：tmanage 前端 `requiresTenantConfiguration` 对 PERSONAL 非 OAuth 返回 false；后端 `requiresTenantInstance` 对所有非 OFFICIAL 的 ADMIN/PERSONAL 返回 true。是否已在线上触发需运行证据，但需求和排障必须同时核对两处。

历史数据允许 provider CSV 多值；下沉时部分字段用“包含 OFFICIAL”，另一些用“仅 OFFICIAL”，存在清值风险。

## 6. 地址字段真义

- `t_tmanage_connector.connector_url`：ERP/SaaS 地址。
- `t_tmanage_sys_cluster_connector.connector_url`：MCP Server 地址。
- kdmanage tenant ERP `connector_url`：ERP 地址。
- kdmanage cluster/mcp_service `connector_url`：MCP Server 地址。
- Hub `server_url`：普通 MCP 接入地址；AK/SK 还可能使用独立 `connector_url` 作为 MC 应用基址。

任何需求若统一按“连接地址”处理，都可能把 ERP Token、版本查询或 MCP 登录打到错误端点。

## 7. 状态不等于链路完成

- HTTP 200 可能只表示接受；self-provision 要看 `overallStatus/stages`。
- `lastPullTime` 可能记录成功或失败尝试，不等于最近成功时间。
- kdmanage PUBLISHED 不表示每个租户已启用实例或发布工具。
- tmanage `instanceEnabled` 不表示派生工具已发布。
- tmanage 目录 OFF_SHELF 不表示已发布工具停止运行。
