# kdmanage 前端工程导航

## 1. 工程概况

- 根目录：`kdmanage-frontend`
- React 18、TypeScript 5.6、Vite 6、Ant Design 6、React Router 6、Zustand。
- basename：`/kdmanage`
- dev 端口：5174；`/kdmanage/api` 默认代理 `http://localhost:18000`。
- packageManager：`pnpm@10.27.0`
- scripts：
  - `pnpm dev`
  - `pnpm dev:mock`
  - `pnpm build`
  - `pnpm typecheck`
- 没有正式 test/lint script；`dev:mock` 仅 mock 用户与菜单，不 mock MCP 业务 API。

## 2. 路由、菜单和权限

关键文件：

- `src/router/index.tsx`
- `src/stores/auth-store.ts`
- `src/components/AppLayout.tsx`

| 路由 | 页面 | 权限前缀 |
|---|---|---|
| `/cluster-connectors` | `ClusterConnectorsPage.tsx` | `environment.cluster_connector` |
| `/mcp-services` | `McpServicesPage.tsx` | `environment.mcp_service` |
| `/mcp-service-connector-types` | `McpServiceConnectorTypesPage.tsx` | `environment.mcp_service_connector_type` |
| `/tenant-erp-connectors` | `TenantErpConnectorsPage.tsx` | `environment.tenant_erp_connector` |
| `/mcp-hub` | `McpHubPage.tsx` | `environment.mcp_hub` |
| `/mcp-types` | `McpTypesPage.tsx` | `environment.mcp_type` |
| `/mcp-providers` | `McpProvidersPage.tsx` | `environment.mcp_provider` |
| `/tenants` | `TenantsPage.tsx` | `operation.tenant` |
| `/publish-review` | `PublishReviewPage.tsx` | `platform.publish_review` |

菜单可见需同时满足 permissions 和 visibleMenus。`ProtectedRoute` 只按页面路径判断，无权限时重定向到首个可访问菜单，不展示明确 403。

目标页面多数没有按钮级 `hasPermission`，写操作安全依赖后端。

## 3. API client

`src/services/api.ts` 集中定义全部 VO 和 client，目标对象：

- `clusterConnectorApi`
- `mcpServiceApi`
- `connectorTypeApi`
- `mcpServiceConnectorTypeApi`
- `tenantErpConnectorApi`
- `tenantApi`
- `mcpApi`
- `mcpTypeApi`
- `mcpProviderApi`
- `publishReviewApi`

请求层：`src/services/request.ts`，默认 `credentials: include`，统一解包后端 `Result<T>`。

## 4. 集群连接器页面

关键文件：`src/pages/ClusterConnectorsPage.tsx`

能力：

- 分页、关键词、状态筛选。
- 新建、配置、删除。
- 连接测试。
- appSecret 二次查看。
- 新集群：账套 -> 领域 -> 远程工具。
- 旧集群兼容：本地 tool-domains -> tools/page。
- 拉取工具和最近成功拉取差异明细。

API：

- `/api/v1/cluster-connectors`
- `/connection-test`
- `/{id}/accounts`
- `/{id}/domains`
- `/{id}/remote-tools`
- `/{id}/tool-domains`
- `/{id}/tools/page`
- `/{id}/pull-tools`
- `/{id}/pull-detail`
- `/{id}/app-secret/reveal`

关键语义：

- 更新带 `version` 做乐观锁。
- 拉取后页面刷新列表，以同步 `lastPullTime` 和 version。
- `tenantEnvCode` 已有值后在配置弹窗锁定。
- `clusterCode` 只读。
- `statusInfo` 只把 `DISABLED` 识别为禁用，未知状态会误显为启用。

已定义未接 UI：`changeStatus`、集群 Swagger 校验/导入。

## 5. 独立 MCP 服务实例页面

关键文件：

- `src/pages/McpServicesPage.tsx`
- `src/pages/McpServiceConnectorTypesPage.tsx`

能力：

- CRUD、连接测试、Secret 查看、工具拉取和详情。
- Swagger JSON 上传 -> 校验 -> 预览 -> 导入。
- 导入结果支持部分成功和失败明细。

API：

- `/api/v1/mcp-services`
- `/connection-test`
- `/{id}/tool-domains`
- `/{id}/tools/page`
- `/{id}/pull-tools`
- `/{id}/validate-swagger`
- `/{id}/import-tools`
- `/{id}/app-secret/reveal`

导入响应的 `version` 会覆盖当前 editing version 并刷新列表，避免后续乐观锁冲突。

已定义未接 UI：`changeStatus`。独立实例没有拉取明细 UI；普通 pull 后也未像集群页一样刷新主列表，存在 lastPullTime/version 陈旧风险。

## 6. 租户 ERP 连接器

只读页面：`src/pages/TenantErpConnectorsPage.tsx`

真实维护入口：`src/pages/TenantsPage.tsx`

租户表单内维护 `erpConnectors` 数组：

- connectorCode/name/productCode/url
- clusterNumber（值为集群的 clusterCode）
- dataCenterId/name/code
- connectorType 由所选集群的 connectorTypeId 反查 typeCode，失败回退 COSMIC

校验：

- 同一租户 connectorCode 大小写不敏感去重。
- dataCenterId 去重。
- 新建行提示默认禁用，密钥和启用在 tmanage 完成。

前端通过 `tenantApi.create/update` 整体提交；服务端如何做增删差异必须看 kdmanage backend。

## 7. MCP Hub 页面

关键文件：

- `src/pages/McpHubPage.tsx`
- `src/pages/McpCreateDialog.tsx`
- `src/pages/McpUpdateDialog.tsx`
- `src/pages/McpHubDetailModal.tsx`
- `src/pages/McpHubVersionModal.tsx`
- `src/components/mcp-hub/*`

页面数据：

- `/api/v1/mcps/hub/stats`
- `/hub/type-counts`
- `/api/v1/mcps`
- `mcpProviderApi.activeList`

状态：`DRAFT`、`PENDING_REVIEW`、`PUBLISHED`、`REJECTED`。

动作：

- 新增、更新版本、详情、版本历史。
- 提交审核。
- 下架。
- 删除非 PUBLISHED。
- resync handler/API 存在，但按钮被注释收起。

## 8. Hub 新建与更新

### 8.1 字段

- mcpCode、中文/英文名称描述。
- 多类型，第一个为主类型。
- 供应商。
- serverType、serverUrl。
- authMethod、paramProviders。
- Header、URL 参数、OAuth、AK/SK。
- tenantScopeType 与 tenantIds。
- 工具清单、visible、testPassed。
- 版本与 changeLog。

### 8.2 鉴权方式

后端支持多种方式，但新建 UI 当前只开放 `BEARER`、`OAUTH2`。更新存量会把当前隐藏方式补回下拉，允许迁移。

- OAuth 授权码锁定 PERSONAL。
- OAuth client credentials 和 AK/SK 禁止 PERSONAL。
- PERSONAL 敏感值只用于本次测试，提交时清空。
- 当前 UI 只允许单个 paramProvider，但库和后端支持 CSV 多值。

### 8.3 连接测试和工具

- `/api/v1/mcps/connection-test`
- `/{id}/aksk-connection-test`
- `/tool-test`
- 非 AK/SK 测试发现资源；可逐工具测试并选择 visible。
- AK/SK 只回域/应用/工具数量，不在 Hub 落逐工具清单。
- 更新时若未重测，沿用详情工具清单。

### 8.4 发布范围

- `ALL`：不传 tenantIds。
- `CUSTOM`：至少一个租户。
- 租户选择走 MCP 自己的 `/tenant-options`，避免要求租户管理权限。

## 9. 类型、供应商和审核

- `McpTypesPage.tsx`：类型 CRUD、启停、多语言、引用数删除保护。
- `McpProvidersPage.tsx`：供应商 CRUD、多语言、来源类型、引用数删除保护；供应商无 status。
- `PublishReviewPage.tsx`：审核列表、预览、通过、驳回；approve timeout 120 秒。

类型必须区分：

1. 集群连接器类型 `/connector-types`
2. 独立 MCP 服务实例连接器类型 `/mcp-service-connector-types`
3. Hub 业务分类 `/mcp-types`
4. 普通工具类型 `/tool-types`

Long 被全局序列化为 string，`mcpCount` 必须先 `Number()`。

## 10. 前端排障检查

1. 检查 `/api/v1/users/me` 的 permissions 和 visibleMenus。
2. 无权限页面会被重定向，不一定显示 403。
3. dev 真实代理为 18000，不要信旧注释里的 8080。
4. 更新冲突先核对 version 是否在 pull/import 后刷新。
5. Secret 保护模式由列表响应 appSecret 是否为空决定；后端改掩码形态会改变分支。
6. PERSONAL 测试成功不代表凭证已持久化。
7. AK/SK 更新测试读取已保存配置，不测试尚未保存的表单新值。
8. `lastPullTime` 是最近尝试时间，pull detail 的时间是最近成功时间。
9. `dev:mock` 不覆盖业务 API，不能据此验证功能。

## 11. 常见需求改动点

| 需求 | 文件 |
|---|---|
| 集群 CRUD/工具/拉取明细 | `ClusterConnectorsPage.tsx`、`api.ts`、`global.css` |
| 独立 MCP/Swagger | `McpServicesPage.tsx`、`api.ts` |
| 租户 ERP 配置 | `TenantsPage.tsx`、`TenantErpConnectorsPage.tsx`、`api.ts` |
| Hub 列表和状态 | `McpHubPage.tsx`、`api.ts` |
| Hub 鉴权/连接测试 | `McpCreateDialog.tsx`、`McpUpdateDialog.tsx`、`components/mcp-hub/*` |
| 发布范围 | `TenantScopeField.tsx`、`TenantPickerModal.tsx`、两个 Dialog |
| 类型/供应商 | `McpTypesPage.tsx`、`McpProvidersPage.tsx` |
| 审核 | `PublishReviewPage.tsx`、`publishReviewApi` |
| 菜单/权限 | `router/index.tsx`、`auth-store.ts`、`AppLayout.tsx` |
