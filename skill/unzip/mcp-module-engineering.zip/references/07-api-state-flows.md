# API、状态机与关键时序

> 路径为应用内映射；直连分别加 `/console`、`/kdmanage`。

## 1. tmanage 前台 API

### 1.1 连接器

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | `/api/connector/list`、`/dc-list` | 列表 |
| GET | `/api/connector/{id}`、`/{id}/mcp-config` | 详情/MCP 配置 |
| GET | `/api/connector/connector-types`、`/provisionable-types`、`/cluster-codes` | 类型与集群选项 |
| GET | `/api/connector/version-requirements`、`/data-centers` | 版本和账套 |
| GET | `/api/connector/{id}/referenced-agents` | 禁用影响 |
| POST | `/api/connector`、`/provision`、`/provision/public` | 三类创建 |
| PUT | `/api/connector/{id}`、`/{id}/status` | 更新/级联启停 |
| DELETE | `/api/connector/{id}` | 删除 |
| POST | `/api/connector/connection-test` | MCP 测试 |
| POST | `/api/connector/{id}/erp-version/fetch` | 拉 ERP 版本 |
| POST | `/api/connector/{id}/kdmanage-provision`、`/erp-fusion` | 公有云开通/公钥融合 |

凭据：`/api/connector-credential` CRUD、sync、private test/version-check、saved test。

集群工具：`POST /api/cluster/{id}/tools/pull`、`GET /pull/status`、`GET /tools`、`GET /tools/{toolId}`。

### 1.2 tmanage 运维预置 Lingee MCP

`GET /api/lingee-mcp/list|{id}/tools`，`POST /{id}/validate-swagger|import-tools`。只服务 `lingeeMcp_` 运维预置对象，不是 kdmanage `lingge_` 独立实例。

### 1.3 Hub

- 目录：`GET /api/mcp-service/page|category-counts|sources|{mcpCode}|{mcpCode}/versions`
- 实例：`POST /instance/enable`，`DELETE /{mcpCode}/instance`
- schema/tools：`GET /{mcpCode}/instance/schema|tools`
- 测试/OAuth：`POST /connection-test|oauth-discovery|oauth-register-client`，以及 OAuth prepare/start/result
- 发布：`POST /{mcpCode}/publish-as-tool`，`DELETE /{mcpCode}/published-tool`

## 2. tmanage backend 下沉 API

- cluster：`POST /api/backend/cluster-connector/sync-upsert|sync-delete|sync-bind`
- ERP：`POST /api/backend/erp-connector/sync-batch-upsert`
- ERP credential：`POST /api/backend/erp-connector/credential/upsert`
- Hub：`POST /api/backend/mcp-service/import`、`POST /{mcpCode}/off-shelf`、`DELETE /{mcpCode}`

依赖共享 BackendAuthFilter 和 backend tenant context，不依赖前台方法权限。

## 3. kdmanage 管理 API

- cluster `/api/v1/cluster-connectors`：CRUD/status/test/accounts/domains/remote-tools/local tools/pull/pull-detail/reveal。
- independent MCP `/api/v1/mcp-services`：CRUD/status/test/tools/pull/reveal/Swagger。
- tenant ERP：`GET /api/v1/tenant-erp-connectors`、`/by-tenant/{tenantId}`；写入嵌入 tenant create/update。
- Hub `/api/v1/mcps`：CRUD/lifecycle/version/test/tool visibility/stats/type counts/check/tenant options/reveal。
- review：`/api/v1/publish-reviews/{id}/approve|reject`。

## 4. kdmanage OpenAPI

- `POST /api/open/v1/tenant-erp-connectors/self-provision`
- `POST /api/open/v1/tenant-erp-connectors/self-provision/public-key`
- `GET /api/open/v1/tenant-erp-connectors/bound-tenants`
- `POST /api/open/v1/erp-credentials/public-key/callback`
- `POST /api/open/v1/erp-credentials/callback`
- `POST /api/open/v1/mcp-services/validate-and-import`

前两个 ERP callback 显式 verify 并以物理 4xx/5xx 控制重试；OpenMcp validate-and-import 当前未见显式 verify。`/api/open/**` 在 Spring Security 层 permitAll。

## 5. 私有连接器时序

```text
step1 ERP URL/type
 -> step2 MCP URL/appId/Secret
 -> POST /connector/provision(N,skipTest)
 -> tmanage 写 sys cluster + connector
 -> step3 credential
 -> MCP test -> ERP test -> version check
 -> update Y 或保留 N
```

connector 存在、无 credential、N 是合法中间态。

## 6. 天梯公有连接器时序

```text
tmanage provision/public
 -> MANUAL+public+N+cluster NULL
 -> kdmanage-provision
 -> kdmanage 按 tenantSn 找租户并取天梯 cluster
 -> upsert cluster + strict sync(按 tenantEnvCode 路由)
 -> upsert tenant connector + strict ERP sync(autoEnable)
 -> payload.tenantTid 实际承载 tenantCode
 -> tmanage 按 tenant_code 找本地 tenant_id
 -> (tenant_id,connectorCode) 命中预建行并回填
```

接口 HTTP 200 后仍需看 overallStatus/stages。

## 7. ERP 密钥时序

```text
确保 RSA 密钥
 -> 同步 tmanage
 -> kwork_erp token
 -> addMcPbKey
 -> 同步返回或 callback
 -> getMcAppInfo
 -> accountId=dataCenterId
 -> credential/upsert
 -> tmanage 解密、写凭据、启用 connector
```

直传产品可 `encryptAlgorithm=NONE`，kdmanage 不落业务 Secret。

## 8. 两种 standalone 时序

### kdmanage 独立 MCP

```text
kdmanage mcp_service CRUD/import/pull
 -> t_kdmanage_mcp_service(+tool)
 -> syncMcpServiceUpsert
 -> 默认 tmanage 目标（不按 tenantEnvCode）
 -> cluster sync-upsert(standalone=true)
 -> tmanage sys cluster / 全局工具
```

### tmanage 运维 Lingee MCP

```text
运维直接预置 lingeeMcp_ sys cluster
 -> tenant 打开 LingeeMcpPanel
 -> 当前 tenant Swagger import
 -> 远端 registry + OLD tool row(tenant_id=current)
 -> 当前 tenant 查看/绑定智能体
```

二者无创建/下沉映射关系。

## 9. 工具拉取状态

### tmanage

`NONE -> ACCEPTED -> RUNNING/FETCHING -> RUNNING/PERSISTING -> DONE/FAILED`。Redis 状态有 TTL；单连接器/租户锁无自动续租。

### kdmanage

同步 HTTP。成功替换或 upsert并更新时间；失败主事务回滚后 REQUIRES_NEW 更新时间；status 不变。cluster 空列表可清空，independent MCP 空列表保留旧工具。

## 10. Hub 生命周期

### kdmanage

```text
DRAFT/REJECTED -> PENDING_REVIEW -> PUBLISHED/REJECTED
PUBLISHED --update/unpublish--> DRAFT
非 PUBLISHED --delete--> soft delete + tmanage delete
PUBLISHED --resync--> import again
```

审核通过只能保证 kdmanage 本地事务，不是分布式事务。

### tmanage 目录

`import -> PUBLISHED`；unpublish -> OFF_SHELF；resync -> 更新/PUBLISHED；delete -> 目录及跨租户清理。

### tmanage 实例

`none -> test/OAuth prepare -> CONFIGURING -> enable -> ENABLED -> disable -> DISABLED+soft delete -> revive`。

后端当前要求所有非 OFFICIAL 的 ADMIN/PERSONAL 发布前有 ENABLED 实例；前端对 PERSONAL 非 OAuth 判断相反，这是已确认源码冲突。

### 派生工具

`catalog -> instance(if required) -> publish -> Tool enabled=1 -> unpublish -> same Tool enabled=0 -> republish/rebuild resources`。目录 OFF_SHELF 不自动 unpublish。

## 11. Secret 三态

- 空：通常不改，但 OAuth scope、xacGwIdentity 等个别字段可清空。
- 全星号：不改。
- 新真值：覆盖。

每个字段必须显式定义，不可统一以非空判断。

## 12. 事务与重试

| 场景 | 语义 |
|---|---|
| 普通 cluster CRUD | 本地事务中阻塞下沉并最多三次重试；失败回滚，sleep 拉长事务 |
| kdmanage independent MCP CRUD | 同上，但走默认 tmanage 目标 |
| self-provision | 每阶段本地提交后严格下沉；允许 FAILED/PARTIAL |
| ERP 常规保存 | 通常 afterCommit 非严格；无事务上下文时需检查是否立即调用 |
| Hub approve | 本地事务包下沉调用，失败回滚 kdmanage；对端可能已成功 |
| Hub unpublish | 本地 DRAFT，远端失败仅 WARN |
| Hub delete | 对端失败回滚本地 |
| tmanage 派生工具停用 | kwork 通知失败回滚 |
| Swagger import | 外部 MCP/DB/tmanage 无分布式事务，可部分成功 |

## 13. HTTP 与业务状态

- tmanage 部分异常可能 HTTP 200 + 业务 code。
- kdmanage Result body 也要解析。
- ERP callback 用物理 4xx/5xx。
- self-provision 用 HTTP 200 + stages。

客户端与排障必须同时看 HTTP 和业务 payload。
