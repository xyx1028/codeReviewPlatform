# kdmanage 后端工程导航

## 1. 工程概况

- 根目录：`kdmanage-backend`
- 主应用：`kdmanage-backend/kdmanage-backend`；公共调用：`kdmanage-common`。
- Java 17、Spring Boot 3.5.3、Spring MVC/WebFlux、Spring Security、MyBatis-Plus、PostgreSQL、Flyway、Redis、Nacos。
- 端口 18000，context path `/kdmanage`。
- Flyway：`kdmanage-backend/src/main/resources/db/migration`。
- 命令：`mvn -pl kdmanage-backend -am -DskipTests compile`、`package`。
- 默认 profile 为 debug，实际线上 profile、Flyway 和 Nacos 覆盖必须运行时确认。

## 2. 领域分层

| 领域 | Controller | Service | Mapper/Repository | 主表 |
|---|---|---|---|---|
| 租户 ERP | TenantErpConnector/Tenant/OpenAPI Controllers | `TenantErpConnectorAppService`、`SelfManagedErpConnectorStageService` | TenantErpConnectorMapper | `t_kdmanage_tenant_erp_connector` |
| 集群连接器 | `ClusterConnectorController` | `ClusterConnectorAppService` | ClusterConnectorRepository/Mapper | `t_kdmanage_cluster_connector` |
| kdmanage 独立 MCP | `McpServiceController`、`OpenMcpServiceController` | `McpServiceAppService` | McpServiceRepository/Mapper | `t_kdmanage_mcp_service` |
| MCP Hub | `McpController` | `service/mcphub/McpHubService` | McpRepository/Hub Mappers | `t_kdmanage_mcp` |
| 类型/供应商 | McpType/McpProvider Controllers | `service/mcphub/McpTypeAppService`、`McpProviderAppService` | Type/Provider/I18n Mappers | `t_kdmanage_mcp_type/provider` |
| 审核 | `PublishReviewController` | `PublishReviewAppService` | PublishReviewMapper | `t_kdmanage_publish_review` |

## 3. 集群连接器

关键文件：ClusterConnectorController/AppService/Repository、TmanageClusterConnectorSyncService、ClusterConnector/Tool Mappers。

### 3.1 CRUD

- clusterCode 为空时后端生成，创建后禁止修改。
- tenantEnvCode 决定目标 tmanage 集群。
- 更新带 version。
- create/update/status/delete 在本地事务内调用 tmanage；失败会回滚。
- 专用 WebClient 最多 3 次重试，重试间 `Thread.sleep` 仍占着本地事务，会拉长锁和连接占用。
- status 当前未见严格 ACTIVE/DISABLED 值域校验。

### 3.2 测试和工具

- SSRF guard 后调 `/api/mcpLogin.do`。
- 新集群优先 `/mcp/registry/tool-names`，旧集群回退 domains/scopes。
- 新协议本地可只存 toolName；旧协议存完整 domain/application/schema。
- 空列表可清空集群本地工具。
- 成败都更新 lastPullTime；失败用 REQUIRES_NEW，状态不随拉取变化。

### 3.3 下沉

payload：clusterCode、name/description、type id/code/name、URL、appId/Secret、status、tenantEnvCode、lastPullTime。目标 `/api/backend/cluster-connector/sync-upsert`。按 tenantEnvCode 解析目标 baseUrl/Secret。

## 4. kdmanage 管理的独立 MCP 服务实例

关键文件：McpServiceController、OpenMcpServiceController、McpServiceAppService/Repository、TmanageClusterConnectorSyncService。

### 4.1 模型和 CRUD

- clusterCode 生成 `lingge_<16位数字>`。
- 应用层查重 name/URL；数据库未见 clusterCode/URL 等价唯一索引，存在并发窗口。
- status 未见严格值域校验。
- 下沉复用 cluster sync，payload `standalone=true`。

### 4.2 与普通集群的重要差异

- `syncMcpServiceUpsert` 固定使用 TmanageClusterConnectorSyncService 的默认 `baseUrl` 与默认 SDK Secret。
- payload 不带 tenantEnvCode，也不按 tenantEnvCode 解析目标。
- 多 tmanage 环境排障时不能照普通集群的环境路由检查。
- 下沉到 tmanage 的 `lingge_...` 是全局共享工具模型，不进入 tmanage 运维预置的 `lingeeMcp_...` 页签。

### 4.3 测试、拉取、Swagger

- 登录后取 domains，再按 scope 调 Gateway tools/list。
- `replaceTools` 对空新列表直接 return，空列表保留旧工具；与集群语义相反。
- Swagger 校验版本/servers/tags/x-domain/operationId/tag/$ref/tool/http/schema。
- 已存在远端工具逐个 PUT，不存在批量 POST；单工具失败可 partial success。
- 成功项本地增量 upsert，不删除历史，然后携全量工具下沉。
- 外部 MCP、数据库、tmanage 无分布式事务，可能远端已写而本地回滚。
- `/api/open/v1/mcp-services/validate-and-import` 未见应用内显式验签，需核对外部网关。

## 5. 租户 ERP 连接器

关键文件：TenantErpConnectorAppService、SelfManagedErpConnectorStageService、ErpCredentialProvisionServiceImpl、TmanageErpConnectorSyncService、Mapper。

### 5.1 管理 replace 与增量路径

- `replaceAll` 同 connectorCode upsert、逻辑删 kdmanage 缺项；新行 N、已有状态保留。
- 校验 connectorCode/dataCenterId 唯一，connectorType 按集群类型派生。
- 还有 incremental、externalTenantId 分组 replace、迁移和删除路径；字段修改必须全部覆盖。
- tmanage 接收是 upsert-only，kdmanage 本地缺项删除不会自动删除对端。

### 5.2 租户标识映射

- 常规同步先选择 tenantCode（优先 tenantSn，空回退 tenantTid），再写入 payload 字段 `tenantTid`。
- tmanage 把该值当 tenantCode 查本地 tenantId。
- self-provision 的 tenantCode 契约固定为 tenantSn，不做 tenantTid 别名匹配。

### 5.3 self-provision

第一接口：按 tenantSn 找租户 -> 从 ERP host 获取天梯集群 -> 按 `(tenantEnvCode,clusterCode)` 锁并 upsert/严格下沉 -> 按 `(tenantId,connectorCode)` upsert/严格下沉 ERP connector(autoEnable)。每阶段独立事务，第二阶段失败返回 PARTIAL_FAILED。

公钥接口：从已存数据重建上下文 -> bindErp -> 确保并同步密钥 -> 获取 kwork_erp token（此路径失败为致命）-> 发布公钥。

### 5.4 常规密钥编排

无连接器/关闭为 SKIPPED；direct product 明文直传但不落 kdmanage；其他产品 RSA-2048 + RSA-OAEP-SHA256。异步产品 PENDING 等回调，以 accountId=dataCenterId 匹配。回调重复投递依赖 tmanage upsert。

常规租户保存通常 afterCommit 非严格同步；self-provision 是严格分阶段同步。无事务同步上下文时部分发布器可能立即调用，分析事务语义要看具体入口。

## 6. MCP Hub

关键文件：McpController、`service/mcphub/McpHubService`、McpEnterpriseResourceSyncService、PublishReviewAppService/Controller、`kdmanage-common/.../TmanageClient`。

### 6.1 创建与更新

创建校验启用类型/供应商、auth/provider、工具/测试、stateless、租户范围，保存 i18n/工具/版本。更新恢复掩码，配置变更使旧测试/stateless 失效，工具守卫无条件执行，非 DRAFT/REJECTED 回 DRAFT，并写版本快照。

### 6.2 生命周期

`DRAFT/REJECTED -> PENDING_REVIEW -> PUBLISHED/REJECTED`；PUBLISHED 更新或下架回 DRAFT；PUBLISHED 禁删；resync 仅 PUBLISHED。

- 审核通过本地事务内结算 expiry 并下沉；下沉失败回滚 kdmanage，但不是分布式事务。
- 普通下架先本地 DRAFT，对端失败只 WARN。
- 真删除对端失败回滚本地。

### 6.3 下沉

McpEnterpriseResourceSyncService 发送基础、类型/供应商、server/auth/provider、Header/URL 参数、OAuth、AK/SK、stateless、expiry、identity、scope、visible 工具、i18n、版本。

- OFFICIAL 可下发平台真值。
- ADMIN/PERSONAL 按归属清值或只发结构。
- 历史多值 provider CSV 的字段判定不一致，见风险清单。
- `TmanageClient` 走 SDK 服务发现/X-Kwork 签名，固定业务租户头 `X-Tmanage-TenantId: kingdee`。
- Hub `postWithRetry` 当前只调用一次；与 cluster/ERP 专用三次重试不同。

## 7. Hub 工具定时刷新

只处理 PUBLISHED + OFFICIAL + 本地已有清单；AK/SK、OAuth 授权码跳过；空清单不覆盖；内容有变化才 merge 并下沉。默认 20/50 分。ADMIN/PERSONAL 由 tmanage 按租户实例刷新。

## 8. 安全

- 管理端 JWT + PermissionAspect；前端菜单不是安全边界。
- `/api/open/**` 在 Spring Security permitAll，Controller 必须显式 verify。
- OpenMcpService validate-and-import 当前未见显式 verify，是待核实高风险。
- 集群 Secret 有 TypeHandler；独立 MCP Secret 未见；Hub OAuth Secret 有 AES；AK/SK Secret 代码与迁移注释冲突；ERP 私钥有 AES。

### Backend HMAC 权威键

kdmanage 出站 signer/default endpoint 和 tmanage 共享 `BackendAuthFilter` 以微服务 SDK 配置为准：

- `kwork.microservice-call.auth.secret-key`

为空时共享 Verifier 不启用。`kwork.backend-auth.*` 可能由其他旧实现消费，不等同于共享 Filter 权威键。排障要确认实际 Filter bean 与配置绑定类。

## 9. 配置

- `manage.sync.mcp.enabled`
- `manage.sync.cluster-connector.enabled`
- `manage.sync.erp-connector.enabled`
- `manage.sync.retry.*`、`manage.sync.timeout-ms`
- `manage.mcp.hub-tool-refresh.*`
- `erp.key-exchange.*`
- `manage.openapi.*`、`manage.jwt.*`
- `kwork.microservice-call.auth.secret-key`
- `manage.tool.url-param-view-password`

真实值以 Nacos/环境变量为准。

## 10. 日志与错误

关键词：`[cluster-sync]`、`[mcp-sync]`、`[ResourceSync]`、`[McpHub]`、`[cluster-connector-test]`、`[mcp-service-test]`、`[swagger-import]`、`[erp-connector-sync]`、`[self-managed-erp]`、`[erp-key-exchange]`、`[erp-credential-provision]`、`[ErpTokenClient]`。

独立 MCP 下沉起点日志是 `[mcp-sync]`，实际 HTTP 重试在共用 `postWithRetry` 中仍打印 `[cluster-sync]`。

典型错误：ERP_CONNECTOR_CODE_REQUIRED/DUPLICATED、ERP_DATA_CENTER_ID_DUPLICATED、CLUSTER_CONNECTOR_NOT_FOUND、CONNECTOR_TYPE_DISABLED、SELF_MANAGED_ERP_*、LINGEE_SECRET_FETCH_FAILED、MCP_SERVER_INFO_*、mcp.not.found、mcp.review.*、mcp.sync.disabled。

## 11. 高影响修改提醒

- Hub 新字段覆盖主表、DTO/Assembler、版本快照、下沉、tmanage import 和运行投影。
- auth/provider 覆盖保存、测试、掩码、审核、下沉清值、实例、发布、运行。
- ERP 字段覆盖 replace、incremental、self-provision、callback、payload。
- 工具拉取分别确认集群和独立 MCP 空列表语义。
- OpenAPI 逐入口核对显式验签。
- 独立 MCP 的默认目标路由若要改为按环境路由，需先给模型补 tenantEnvCode/目标归属和存量迁移。
