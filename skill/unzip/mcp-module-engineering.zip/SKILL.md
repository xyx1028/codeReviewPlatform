---
name: mcp-module-engineering
description: 处理 tmanage、kdmanage 中连接器、集群连接器、独立 MCP 服务实例及 MCP Hub 租户实例相关需求与故障。用户要求新增或修改功能、定位接口与数据、排查同步、拉取、鉴权、发布问题，或评估跨前后端影响时使用。
whenToUse: 涉及 tmanage 或 kdmanage 的连接器、集群连接器、MCP 服务实例、MCP Hub、工具拉取与跨系统下沉时
---

# MCP 模块工程助手

本技能用于在以下四个工程中处理 MCP 模块需求和故障：

- `tmanage-frontend`：租户控制台前端
- `tmanage-backend`：租户控制台后端
- `kdmanage-frontend`：平台运营端前端
- `kdmanage-backend`：平台运营端后端

知识快照基于 **2026-09-17** 的工作区代码。代码持续演进，文档与当前代码冲突时，以当前代码、数据库迁移和真实运行结果为准。

# 一、先做概念判定

接到需求后，必须先判断对象属于哪条链路，不允许把名称相似的对象混为一谈：

1. **租户连接器（ERP 连接器）**
   - kdmanage：`t_kdmanage_tenant_erp_connector`
   - tmanage：`t_tmanage_connector`、`t_tmanage_connector_credential`
   - 含义：某租户、某数据中心使用哪个 ERP 环境及哪个 MCP 集群。
2. **集群连接器**
   - kdmanage：`t_kdmanage_cluster_connector`
   - tmanage：`t_tmanage_sys_cluster_connector`
   - 含义：平台登记的 MCP 集群入口，供租户连接器按 `clusterCode` 引用。
3. **独立运行的 MCP Server**，又分两种，不得互相映射：
   - **kdmanage 管理的独立 MCP 服务实例**：`t_kdmanage_mcp_service`，编码通常为 `lingge_...`；以 `standalone=true` 下沉到 tmanage 系统集群表，工具全局共享。它不进入 tmanage“灵基MCP”页签。
   - **tmanage 运维预置的灵基MCP**：运维直接预置 `t_tmanage_sys_cluster_connector`，编码为 `lingeeMcp_...`；连接器全局共享、工具按租户隔离，展示在 tmanage“灵基MCP”页签。它不是 kdmanage MCP 服务实例的前端投影。
4. **MCP Hub 模板与租户实例**
   - kdmanage 模板：`t_kdmanage_mcp` 及类型、供应商、工具、版本、范围子表。
   - tmanage 目录：`t_tmanage_mcp`。
   - tmanage 租户实例：`t_tmanage_mcp_instance`、`t_tmanage_mcp_instance_credential`。
   - 发布后的运行投影：`t_tmanage_tool`、`t_tmanage_tool_resource`，以 `source_mcp_code` 标识来源。

若用户只说“MCP 实例”，先根据页面、接口、编码前缀、表名和字段判定具体对象；仍无法判断时再询问。

# 二、事实优先级

处理需求或排障时按以下顺序取证：

1. 本轮真实运行结果：HTTP 响应、日志、数据库只读查询、测试结果。
2. 当前分支源码与当前生效的 Flyway 迁移。
3. 配置中心和部署环境中的实际配置。
4. 本技能 references 文档。
5. 注释、旧设计文档和历史迁移中的描述。

不得仅凭本技能宣称线上配置、数据库数据、网络连通性或构建测试已经确认。敏感字段只能确认“是否配置”，不得输出明文密钥、Token、私钥或完整认证头。

# 三、按任务选择资料

先读 `references/00-reading-map.md`，再按任务加载：

- 概念、职责边界、跨系统调用：`01-domain-and-architecture.md`
- tmanage 前端：`02-tmanage-frontend.md`
- tmanage 后端：`03-tmanage-backend.md`
- kdmanage 前端：`04-kdmanage-frontend.md`
- kdmanage 后端：`05-kdmanage-backend.md`
- 表、字段、业务键：`06-data-model.md`
- API、状态机、完整时序：`07-api-state-flows.md`
- 权限、鉴权、配置、定时任务：`08-security-config-operations.md`
- 故障定位：`09-troubleshooting.md`
- 需求改动面：`10-change-impact.md`
- 已知风险和契约漂移：`11-known-risks.md`
- 文件与 symbol 定位：`12-source-index.md`

# 四、需求开发流程

## 1. 圈定对象与权威端

输出以下判断：

- 业务对象属于上述哪一类和哪一种子型。
- 谁拥有主数据：kdmanage、tmanage 还是 tmanage 运维预置。
- 谁是写入入口，谁是下沉或运行投影。
- 跨系统业务键是什么。ERP 链路不是简单的 `tenantSn + tenantTid` 复合键：发送端通常从 tenantSn/tenantTid 中选择一个作为 tenantCode，tmanage 再解析为本地 tenantId，最终按 `(tenant_id, connector_code)` upsert。
- 不要拿两端数据库主键直接关联。

## 2. 还原现有链路

至少定位：

- 前端路由、页面、API client、类型。
- 后端 Controller、Service、Mapper、实体/DTO。
- 数据表、迁移、唯一约束。
- 权限、租户上下文、敏感字段处理。
- 下沉入口、目标路由、重试、事务边界、缓存或定时任务。

## 3. 做影响分析

按 `references/10-change-impact.md` 检查：

- 前后端契约是否同时修改。
- kdmanage → tmanage payload 是否补字段。
- 新建、编辑、同步、复活、停用、删除、版本快照是否都覆盖。
- 列表、详情、连接测试、定时刷新、发布运行投影是否都覆盖。
- 数据库迁移是否只增不改旧脚本，是否有幂等 DDL、索引和历史数据处理。
- 掩码的“空 / 掩码 / 新值”三态是否保持。

## 4. 实施与验证

只修改必要文件。优先运行受影响工程的最小验证：

- `tmanage-frontend`：`npm run build`；已有相关测试时运行 `npm run test`。执行前确认团队实际包管理器，避免无意重写 lockfile。
- `kdmanage-frontend`：`pnpm typecheck`、`pnpm build`。
- `tmanage-backend`：在 `tmanage-backend` 根目录候选命令为 `mvn -pl tmanage -am -DskipTests compile`；仓库未定义唯一权威本地启动命令，必须以本轮真实执行结果为准。
- `kdmanage-backend`：`mvn -pl kdmanage-backend -am -DskipTests compile`，必要时运行定向测试。

不要因文档存在就假定命令可运行；必须观察真实退出码。

## 5. 输出需求结论

使用 `templates/requirement-analysis.md`，至少包含：对象归属、现有链路、改动文件、数据/API 变化、兼容与安全风险、验证证据、未验证项。

# 五、故障排查流程

1. 收集最小事实：环境、时间窗、租户标识、`connectorCode/clusterCode/mcpCode`、请求 URL、HTTP 状态、业务 code/message，以及真实传播的 traceId。requestId 若只存在调用方本地日志，只能用于该系统内部检索。
2. 判定故障层：前端权限/路由、入口 API、跨系统下沉、租户上下文、数据库主数据、外部 MCP/ERP、工具存储、缓存/定时任务、发布运行投影。
3. 从写入源向消费端逐层验证，不要一开始就改数据。
4. 使用 `references/09-troubleshooting.md` 中的日志关键词和只读核对项。
5. 结论必须区分：
   - 已证实根因
   - 高概率假设
   - 尚缺证据
6. 修复前说明影响和回滚方式；生产写库、补推、删除、重放等高风险动作必须先征得明确确认。
7. 使用 `templates/incident-investigation.md` 输出证据链。

# 六、必须遵守的工程规则

- 不把 `connector_url` 一概解释为同一种地址：`t_tmanage_connector.connector_url` 的当前权威语义是 ERP/SaaS 地址；MCP Server 地址在系统集群表。
- 不把 `clusterNumber` 和数据库主键混用；它对应业务键 `clusterCode`。
- 不把 `lingge_` 与 `lingeeMcp_` 当成前缀漂移；它们是两种独立部署模型。
- 不把 OFFICIAL、ADMIN、PERSONAL 当展示标签处理；它们决定凭证所有权、实例是否必需及下沉清值规则。
- 不通过前端权限推断安全边界，必须检查后端注解、Filter/AOP 与开放接口显式验签。
- 不回显或记录 Secret。日志和排障 SQL避免查询 `app_secret`、`headers_json` 真值、OAuth Secret、Token、私钥；URL 只展示去 query 的部分。
- 不修改已发布 Flyway 脚本；新增迁移并确认真正扫描目录是主应用的 `src/main/resources/db/migration`。
- 不把“请求成功”当成“全链路完成”：开通、审核、下沉、回调和工具拉取各有独立阶段与中间态。
- 发现文档与代码冲突时记录到结论，不静默选一边。
